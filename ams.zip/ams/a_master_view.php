
	<?php 
			session_start();
			include 'db_connect.php';
			if(isset ($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';
					$assert_type = $_GET['assert_type'];
					$assert_category = $_GET['assert_category'];
					$assert_name = $_GET['assert_name']; 
					$assert_item_code = $_GET['assert_item_code'];
					$assert_brand = $_GET['assert_brand'];
					$assert_model = $_GET['assert_model'];
					$assert_location = $_GET['assert_location'];
					//$completion_date = $_POST['completion_date'];
					//$assert_warranty_period = $_POST['assert_warranty_period'];
					
					/*echo "assert_type : ".$assert_type;
					echo "assert_category: ".$assert_category;
					echo "assert_name : ".$assert_name;
					echo "item_code : ".$item_code;
					echo "brand: ".$brand;
					echo "model : ".$model;
					echo "location : ".$location;
					echo "completion_date: ".$completion_date;
					echo "assert_warranty_period : ".$assert_warranty_period;*/
					
					$filter = "1=1 ";
					
					if(isset($_GET['assert_id']) && ($_GET['assert_id']!=''))
					{
						$filter .= " AND `assert_id` LIKE '%".$_GET['assert_id']."%'";
					}
					
					if(isset($_GET['assert_type']) && ($_GET['assert_type']!='0'))
					{
						$filter .= " AND `assert_type` = '".$_GET['assert_type']."'";
					}
					
					
					if(isset($_GET['assert_category']) && ($_GET['assert_category']!='0'))
					{
						$filter .= " AND `assert_category` = '".$_GET['assert_category']."'";
					}	
					
					if(isset($_GET['assert_name']) && ($_GET['assert_name']!=''))
					{
						$filter .= " AND `assert_name` LIKE '%".$_GET['assert_name']."%'";
					}
					
					if(isset($_GET['assert_item_code']) && ($_GET['assert_item_code']!=''))
					{
						$filter .= " AND `assert_item_code` LIKE '%".$_GET['assert_item_code']."%'";
					}     
					
					
					if(isset($_GET['assert_location']) && ($_GET['assert_location']!='0'))
					{
						$filter .= " AND `assert_location` = '".$_GET['assert_location']."'";
					}
						
					
					if(isset($_GET['assert_brand']) && ($_GET['assert_brand']!=''))
					{
						$filter .= " AND `assert_brand` LIKE '%".$_GET['assert_brand']."%' ";
					}
					
					if(isset($_GET['assert_model']) && ($_GET['assert_model']!=''))
					{
						$filter .= " AND `assert_model` LIKE '%".$_GET['assert_model']."%' ";
						
					}
					
					if(isset($_GET['completion_date']) && ($_GET['completion_date']!=''))
					{
						$filter .= " AND `completion_date` LIKE '%".$_GET['completion_date']."%' ";
						
					}
					
					if(isset($_GET['assert_warranty_period']) && ($_GET['assert_warranty_period']!=''))
					{
						$filter .= " AND `assert_warranty_period` LIKE '%".$_GET['assert_warranty_period']."%' ";
						
					}
					 $view = "SELECT 
									`assert_id`,`assert_type`,`assert_category`,`assert_name`,`assert_item_code`,`assert_brand`,`assert_model`,
									`assert_location`,`completion_date`,`assert_warranty_period` 
								FROM 
									tbl_assert_master_system 
								WHERE 
									$filter";
				    //echo '2222';
				    
					$result = $conn->query($view);

							
			}
			else{
				echo "Invalid Calling Method!";
				
			}
        //echo 'mklslkfjsafj';
			
					
?>
			
<div class="container">
   <br/>
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading"></div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Assert Type</th>
								<th>Assert Category</th>
								<th>Assert Name</th>
								<th>Item Code</th>
								<th>Brand</th>
								<th>Model</th>
								<th>Location</th>
								<th>Date of Production</th>
								<th>Warranty</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
						?>
						
							<tr>
							    <td><?php echo $row['assert_id']; ?></td>
								<td><?php echo $row['assert_type']; ?></td>
								<td><?php echo $row['assert_category']; ?></td>
								<td><?php echo $row['assert_name']; ?></td>
								<td><?php echo $row['assert_item_code']; ?></td>
								<td><?php echo $row['assert_brand']; ?></td>
								<td><?php echo $row['assert_model']; ?></td>
								<td><?php echo $row['assert_location']; ?></td>
								<td><?php echo $row['completion_date']; ?></td>
								<td><?php echo $row['assert_warranty_period']; ?></td>
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['assert_id'].'" id="edit"><a href="edit_assert.php?assert_id=<?php echo $row['assert_id'];?>"> Edit </a></button>
                                 <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['assert_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['assert_id'].'" id="delete"> Delete </button></td>
								 <?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
							
							
							</tr>
						<?php
							}
						?>
						</tbody>
							
						</table>
					</div>
					</div>
				</div>
	</hr>

</div>
