<?php include 'template/header.php'; ?>


<?php
	include 'db_connect.php';
	

	$agent = "SELECT `agent_id`,`agent_code` FROM tbl_agent_info WHERE `agent_active_status` = 1 ORDER BY `agent_code` asc";
	
	
	$result_agnt = $conn->query($agent);
	

	$category = "SELECT `user_category_id`,`user_category_type` FROM tbl_user_category_info WHERE `user_active_status` = 1 ORDER BY `user_category_type` asc";
	
	$result_cat = $conn->query($category);
	
	
	$user_level = "SELECT `user_level_id`,`user_level_name`,`user_level_no`  FROM tbl_user_level WHERE `user_level_active_status` = 1 ORDER BY `user_level_no` asc";
	
	$result_user_level = $conn->query($user_level);
	
	
?>


			<?php
					if(isset($_POST['add']))
					{	 
						    
							$user_category = $_POST['user_category'];
							$user_institute = $_POST['user_institute'];
							$user_f_name = $_POST['user_f_name'];
							$user_l_name = $_POST['user_l_name'];
							$user_full_name = $_POST['user_full_name'];
							$user_nic_no = $_POST['user_nic_no'];
							$user_email = $_POST['user_email'];
							$user_mobile = $_POST['user_mobile'];
							$user_address = $_POST['user_address'];
							$user_company_id = $_POST['user_company_id'];
							$user_name = $_POST['user_name'];
							$user_password = $_POST['user_password'];
							$date_of_join = $_POST['date_of_join'];
							$user_position = $_POST['user_position'];
							$user_level = $_POST['user_level'];
							/*$user_active_status = $_POST['user_active_status'];
							$user_added_by = $_POST['user_added_by'];
							$user_added_date = $_POST['user_added_date'];
							$user_last_date = $_POST['user_last_update'];
							$user_last_update_by = $_POST['user_last_update_by'];*/
							
							$sql = "INSERT INTO tbl_system_user(
							user_category,user_institute,user_f_name,user_l_name,user_full_name,user_nic_no,
							user_email,user_mobile,user_address,user_company_id,user_name,user_password,
							date_of_join,user_position,user_level,user_active_status,user_added_by,user_added_date,user_last_update,user_last_update_by)
							
							VALUES ( 
							'".$user_category."','".$user_institute."','".$user_f_name."','".$user_l_name."','".$user_full_name."','".$user_nic_no."',
							'".$user_email."','".$user_mobile."','".$user_address."','".$user_company_id."','".$user_name."','".$user_password."',
							'".$date_of_join."','".$user_position."','".$user_level."',1,111,NOW(),
							111,NOW())";
							
							//$_SESSION['user_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
			?>
			 

<form action="" method="POST">


<div class="container mt-5">
  <div class="row pt-6"><center>
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black">Add New User</font></label></b></center>
	</div><br>
	

	
  <div class="row pt-2">
			<div class="col-sm-2">
			<label for="user_category" id="preinput">Type of User</label>
			</div>
			<div class="col-sm-1">
				<label for="user_category" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<!--
				  <select name="user_category" id="user_category">
				  <option value="select"></option>
				  <option value="">Super Admin</option>
				  <option value="">Admin</option>
				  <option value="">User</option>
				  </select>
				  -->
				  
				  <?php
				  
				  ?>
				  <select name="user_category" style="width:220px; height:35px" class="form-control" id="failure">
					  <option value="select"></option>
					  <?php 
						while($row = $result_cat->fetch_assoc()) {
					  ?>
						<option value="<?php echo $row['user_category_id'];?>">
						<?php echo $row['user_category_type'];?></option>
					  <?php
						}
					  ?>
				  </select>
			</div> 
					
					<div class="col-sm-1"></div>
			
					<div class="col-sm-2">
					<label for="user_mobile" id="preinput">Mobile No</label>
					</div>
					<div class="col-sm-1">
						<label for="user_mobile" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_mobile" id="inputid">
					</div>
					<div class="col-sm-1"></div>
			
  </div> 
  
  <div class="row pt-2">
			<div class="col-sm-2">
			<label for="user_institute" id="preinput">Agency</label>
			</div>
			<div class="col-sm-1">
				<label for="user_institute" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <!-- 
				  <select name="institute" id="failure">
					  <option value="select"></option>
					  <option value="">Makubura</option>
					  <option value="">Kadawatha</option>
					  <option value="">Kandy</option>
				  </select>
				  -->
				  
				  <?php
				  
				  ?>
				  <select name="user_institute" style="width:220px; height:35px" class="form-control" id="failure">
					  <option value="select"></option>
					  <?php 
						while($row = $result_agnt->fetch_assoc()) {
					  ?>
						<option value="<?php echo $row['agent_id'];?>">
						<?php echo $row['agent_code'];?></option>
					  <?php
						}
					  ?>
				  </select>
			</div>

			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
			<label for="user_company_id" id="preinput">Company ID</label>
			</div>
			<div class="col-sm-1">
				<label for="user_company_id" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			<input type="text" class="form-control" style="width:220px; height:35px" name="user_company_id" id="inputid">
			</div>			
			
					
  </div>
  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_position" id="preinput">Position</label>
					</div>
					<div class="col-sm-1">
						<label for="user_position" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_position" id="inputid">
					</div>

					<div class="col-sm-1"></div>
					    
					<div class="col-sm-2">
					<label for="user_name" id="preinput">User Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_name" id="inputid">
					</div> 
								

  </div>
  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_full_name" id="preinput">User Full Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_full_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_full_name" id="inputid">
					</div> 
					
					<div class="col-sm-1"></div>
					
					<div class="col-sm-2">
					<label for="user_password" id="preinput">Password</label>
					</div>
					<div class="col-sm-1">
						<label for="user_password" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="password" class="form-control" style="width:220px; height:35px" name="user_password" id="inputid">
					</div> 
			
					
  </div>
  

  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_f_name" id="preinput">First Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_f_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_f_name" id="inputid">
					</div>

					
					<div class="col-sm-1"></div>
			
					<div class="col-sm-2">
					<label for="date_of_join" id="preinput">Date of Join</label>
					</div>
					<div class="col-sm-1">
						<label for="date_of_join" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="date" class="form-control" style="width:220px; height:35px" name="date_of_join" id="inputid">
					</div>
  </div>
  
    
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_l_name" id="preinput">Last Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_l_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_l_name" id="inputid">
					</div> 	

					<div class="col-sm-1"></div>
							
					<div class="col-sm-2">
					<label for="user_level" id="preinput">User Level</label>
					</div>
					<div class="col-sm-1">
						<label for="user_level" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
							  <?php
							  
							  ?>
							  <select name="user_level" style="width:220px; height:35px" class="form-control" id="failure">
								  <option value="select"></option>
								  <?php 
									while($row = $result_user_level->fetch_assoc()) {
								  ?>
									<option value="<?php echo $row['user_level_no'];?>">
									<?php echo $row['user_level_name'];?></option>
								  <?php
									}
								  ?>
							  </select>
					</div> 
  </div>
  

  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_email" id="preinput">E-mail</label>
					</div>
					<div class="col-sm-1">
						<label for="user_email" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_email" id="inputid">
					</div> 
					
  </div>
  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_address" id="preinput">Address</label>
					</div>
					<div class="col-sm-1">
						<label for="user_address" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_address" id="inputid">
					</div>

					
  </div>
  

  
    
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_nic_no" id="preinput">NIC No</label>
					</div>
					<div class="col-sm-1">
						<label for="user_nic_no" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" style="width:220px; height:35px" name="user_nic_no" id="inputid">
					</div> 
					
					<div class="col-sm-1"></div>
					
					<div class="col-sm-2">
					
					</div>
					<div class="col-sm-1">
						<button type="submit" name="add" style="background-color:gray; width:100px; height:40px;">Submit</button>
					</div>
					<div class="col-sm-2">
					
					</div>
  </div>
   
 </div>
 </form>
 

<?php include 'template/footer.php'; ?>