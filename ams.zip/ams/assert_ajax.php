<?php 
			
	include 'db_connect.php';
			
		if((isset($_POST['del_id'])) && ($_POST['del_id']>0)){
				$delete ="UPDATE 
							tbl_assert_master_system 
						  SET
							`assert_active_status` = 0
						  WHERE
							`assert_id`='".$_POST['del_id']."'
							";
				
				$result_del = $conn->query($delete);
		}
		
		
	/*	

    if((isset($_POST['keyword'])) && ($_POST['keyword']!= '')){
				echo '<ul id="assert-list">';

        foreach($result as $assert) {
	
	    $fltr = "SELECT 
					`assert_brand`,`assert_model`,`assert_name`,`assert_responsible_division`,`completion_date`,`assert_warranty_period`,
					`assert_amount_insured` 
				  FROM 
					tbl_assert_master_system  
				  WHERE 
				  `assert_brand` LIKE '%".$_POST['keyword']."%' 
				  or
				   `assert_model` LIKE '%".$_POST['keyword']."%'  
				  or
				  `assert_name` LIKE '%".$_POST['keyword']."%'
				  or
				  `assert_responsible_division` LIKE '%".$_POST['keyword']."%'
				  or
				  `completion_date` LIKE '%".$_POST['keyword']."%'
				  or
				  `assert_warranty_period` LIKE '%".$_POST['keyword']."%'
				  or
				  `assert_amount_insured` LIKE '%".$_POST['keyword']."%'";
				  
				   if($result = mysqli_query($conn, $fltr)){
							   if(mysqli_num_rows($result) > 0){ 
							//Store the result in an array list[]

								 while($row = mysqli_fetch_array($result)){
								 $list[] = $row['assert_brand'];
								 $list[] = $row['assert_model'];
								 $list[] = $row['assert_name'];
								 $list[] = $row['assert_responsible_division'];
								 $list[] = $row['completion_date'];
								 $list[] = $row['assert_warranty_period'];
								 $list[] = $row['assert_amount_insured'];
								}
							   }else{
							//set a null value to list[] if no result to prevent error

								$list[] = "";
							   }
							  }

							  if(!empty($value)){
							   if($matched = preg_grep('~'.$value.'~i', $list)){
							   $count = 0;
							   echo '<ul>';
								while($count < sizeOf($list)){
								 if(isset($matched[$count])){

					 echo '<li onClick="selectBrand('.$assert["assert_brand"].');">'.$assert["assert_brand"].'</li>'
						   '<li onClick="selectmodel('.$assert["assert_model"].');">'.$assert["assert_model"].'</li>'
						   '<li onClick="selectname('.$assert["assert_name"].');">'.$assert["assert_name"].'</li>'
						   '<li onClick="selectDivision('.$assert["assert_responsible_division"].');">'.$assert["assert_responsible_division"].'</li>'
						   '<li onClick="selectDate('.$assert["completion_date"].');">'.$assert["completion_date"].'</li>'
						   '<li onClick="selectWarranty('.$assert["assert_warranty_period"].');">'.$assert["assert_warranty_period"].'</li>'
						   '<li onClick="selectInsurance('.$assert["assert_amount_insured"].');">'.$assert["assert_amount_insured"].'</li>'
						}
			 $count++;
			}
			echo '</ul>';
			
			echo json_encode($data);
   }else{
    echo "No result";
   }
		
}*/

					$keyword = $_POST['assert_item_code'];
					$suggesstion_box = [];

					if((isset($_POST['keyword'])) && ($_POST['keyword']!= '')){
						
						$sql = "SELECT 
									  `assert_brand`,`assert_model`,`assert_name`,`assert_responsible_division`,`completion_date`,`assert_warranty_period`,
									  `assert_amount_insured` 
								FROM 
									   tbl_assert_master_system  
								WHERE 
									  `assert_brand` LIKE '%".$_POST['keyword']."%' 
									  or
									   `assert_model` LIKE '%".$_POST['keyword']."%'  
									  or
									  `assert_name` LIKE '%".$_POST['keyword']."%'
									  or
									  `assert_responsible_division` LIKE '%".$_POST['keyword']."%'
									  or
									  `completion_date` LIKE '%".$_POST['keyword']."%'
									  or
									  `assert_warranty_period` LIKE '%".$_POST['keyword']."%'
									  or
									  `assert_amount_insured` LIKE '%".$_POST['keyword']."%'";
									  
						$result = mysqli_query($conn, $sql);

						if(mysqli_num_rows($result) > 0) {
							while($row = mysqli_fetch_array($result)) {
								array_push($suggesstion_box, $row["assert_brand"], $row["assert_model"], $row["assert_name"], $row["assert_responsible_division"]
											$row["completion_date"], $row["assert_warranty_period"], $row["assert_amount_insured"]);
											echo '<li onClick="selectBrand('.$assert["assert_brand"].');">'.$assert["assert_brand"].'</li>'
							}
						}
						
				  /* echo  '<li onClick="selectBrand('.$assert["assert_brand"].');">'.$assert["assert_brand"].'</li>'
						   '<li onClick="selectmodel('.$assert["assert_model"].');">'.$assert["assert_model"].'</li>'
						   '<li onClick="selectname('.$assert["assert_name"].');">'.$assert["assert_name"].'</li>'
						   '<li onClick="selectDivision('.$assert["assert_responsible_division"].');">'.$assert["assert_responsible_division"].'</li>'
						   '<li onClick="selectDate('.$assert["completion_date"].');">'.$assert["completion_date"].'</li>'
						   '<li onClick="selectWarranty('.$assert["assert_warranty_period"].');">'.$assert["assert_warranty_period"].'</li>'
						   '<li onClick="selectInsurance('.$assert["assert_amount_insured"].');">'.$assert["assert_amount_insured"].'</li>'
						
						 $count++; */
					
						echo '</ul>';

						mysqli_close($conn);

						echo json_encode($suggesstion_box);
					}

?>