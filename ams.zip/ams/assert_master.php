<?php include 'template/header.php'; ?>

  

<?php
	include 'db_connect.php';
	

	$ownership = "SELECT `owner_code`,`owner_type` FROM tbl_ownersip_info WHERE `owner_active_status` = 1 ORDER BY `owner_type` asc";
	
	
	$result_own = $conn->query($ownership);
	

	$assert = "SELECT `assert_name`,`assert_code` FROM tbl_asser_category WHERE `assert_active_status` = 1 ORDER BY `assert_name` asc";
	
	$result_ass = $conn->query($assert);
	
	
	$location = "SELECT `location_id`,`location_name` FROM tbl_location_info WHERE `location_active_status` = 1 ORDER BY `location_name` asc";
	
	$result_loca = $conn->query($location);
	
	
?>

<?php
					if(isset($_POST['save']))
					{	 
						    
							$assert_type = $_POST['assert_type'];
							$assert_ownership = $_POST['assert_ownership'];
							$assert_category = $_POST['assert_category'];
							$assert_name = $_POST['assert_name'];
							$assert_item_code = $_POST['assert_item_code'];
							$assert_brand = $_POST['assert_brand'];
							$assert_model = $_POST['assert_model'];
							$assert_unit_of_measurement = $_POST['assert_unit_of_measurement'];
							$assert_capacity = $_POST['assert_capacity'];
							$assert_location = $_POST['assert_location'];
							$assert_warranty_period = $_POST['assert_warranty_period'];
							$assert_invoiced_amount = $_POST['assert_invoiced_amount'];
							$completion_date = $_POST['completion_date'];
							$assert_amount_insured = $_POST['assert_amount_insured'];
							$assert_responsible_division = $_POST['assert_responsible_division'];
							$assert_supplier = $_POST['assert_supplier'];
							$assert_supplier_address = $_POST['assert_supplier_address'];
							$assert_file_no = $_POST['assert_file_no'];
							$assert_service_agreement = $_POST['assert_service_agreement'];
							$assert_frequency = $_POST['assert_frequency'];
							$assert_milage = $_POST['assert_milage'];
							$expected_time = $_POST['expected_time'];
							$description = $_POST['description'];
							$instructions = $_POST['instructions'];
							
							$sql = "INSERT INTO tbl_assert_master_system(
							assert_type,assert_ownership,assert_category,assert_name,assert_item_code,assert_brand,
							assert_model,assert_unit_of_measurement,assert_capacity,assert_location,assert_warranty_period,
							assert_invoiced_amount,completion_date,assert_amount_insured,assert_responsible_division,assert_supplier,assert_supplier_address
							,assert_file_no,assert_service_agreement,assert_frequency,assert_milage,expected_time,description,instructions,assert_active_status)
							
							VALUES ( 
							'".$assert_type."','".$assert_ownership."','".$assert_category."','".$assert_name."','".$assert_item_code."','".$assert_brand."',
							'".$assert_model."','".$assert_unit_of_measurement."','".$assert_capacity."','".$assert_location."','".$assert_warranty_period."',
							'".$assert_invoiced_amount."','".$completion_date."','".$assert_amount_insured."','".$assert_responsible_division."',
							'".$assert_supplier."','".$assert_supplier_address."','".$assert_file_no."','".$assert_service_agreement."',
							'".$assert_frequency."','".$assert_milage."','".$expected_time."','".$description."',
							'".$instructions."',1)";
							
							//$_SESSION['assert_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
			?>

<form action="" method="POST">

<div class="container mt-5">
  <div class="row pt-6"><center>
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black">Create Item</font></label></b></center>
	</div><br>
 		
  
	    <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_type" id="preinput">Assert Type</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_type" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_type" style="width:220px; height:35px" id="assert_type" class="form-control">
				  <option value="select"></option>
				  <option value="fixed">Fixed</option>
				  <option value="movable">Movable</option>
				  <option value="other">Other</option>
				  </select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_amount_insured" id="preinput">Amount of Insured</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_amount_insured" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_amount_insured" id="inputid">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_ownership" id="preinput">Ownership</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_ownership" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			<!--
				  <select name="assert_ownership" id="assert_ownership">
				  <option value="select"></option>
				  <option value="own">Own</option>
				  <option value="hired">Hired</option>
				  <option value="other">Other</option>
				  </select>
			-->
				  
				  <?php
				  
				  ?>
				  <select name="assert_ownership" style="width:220px; height:35px" class="form-control" id="failure">
					  <option value="select"></option>
					  <?php 
						while($row = $result_own->fetch_assoc()) {
					  ?>
						<option value="<?php echo $row['owner_code'];?>">
						<?php echo $row['owner_type'];?></option>
					  <?php
						}
					  ?>
					  
					</select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_responsible_division" id="preinput">Responsible Division</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_responsible_division" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_responsible_division" style="width:220px; height:35px" class="form-control" id="assert_responsible_division">
				  <option value="select"></option>
				  <option value="facility">Facility Management</option>
				  <option value="it">IT</option>
				  <option value="transport">Transport</option>
				  <option value="admin">Admin</option>
				  </select>
			</div>
			
	   </div>
		
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_category" id="preinput">Assert Category</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_category" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			<!--
				  <select name="assert_category" id="assert_category">
				  <option value="select"></option>
				  <option value="maintenance">Maintenance</option>
				  <option value="removable">Removable</option>
				  <option value="elecronic">Electronic</option>
				  <option value="electrical">Electrical</option>
				  <option value="motor">Motor</option>
				  <option value="furniture">Furniture</option>
				  <option value="consumer">Consumer</option>
				  <option value="other">Other</option>
				  </select>
			-->
			
			      <?php
				  
				  ?>
				  <select name="assert_category" style="width:220px; height:35px" class="form-control" id="failure">
					  <option value="select"></option>
					  <?php 
						while($row = $result_ass->fetch_assoc()) {
					  ?>
						<option value="<?php echo $row['assert_code'];?>">
						<?php echo $row['assert_name'];?></option>
					  <?php
						}
					  ?>
					  
				</select>
			
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_supplier" id="preinput">Supplier</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_supplier" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_supplier" id="inputid">
			</div>
			

	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_name" id="preinput">Assert Name</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_name" id="inputid">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_supplier_address" id="preinput">Supplier Address</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_supplier_address" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_supplier_address" id="inputid">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_item_code" id="preinput">Item Code</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_item_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_item_code" id="inputid">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_file_no" id="preinput">File No.</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_file_no" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_file_no" id="inputid">
			</div>
			
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_brand" id="preinput">Brand</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_brand" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_brand" id="inputid">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_service_agreement" id="preinput">Service Agreement</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_service_agreement" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_service_agreement" style="width:220px; height:35px" class="form-control" id="assert_service_agreement">
				  <option value="select"></option>
				  <option value="supplier">Supplier</option>
				  <option value="contact">Contact Person</option>
				  <option value="address">Address</option>
				  <option value="details">Contact Detail</option>
				  </select>
			</div>
			

			
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_model" id="preinput">Model</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_model" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_model" id="inputid">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_frequency" id="preinput">Frequency of Maintainance</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_frequency" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_frequency" style="width:220px; height:35px" class="form-control" id="assert_frequency">
				  <option value="select"></option>
				  <option value="weekly">Weekly</option>
				  <option value="monthly">Monthly</option>
				  <option value="quartly">Quartly</option>
				  <option value="annually">Annually</option>
				  </select>
			</div>	
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_unit_of_measurement" id="preinput">Unit of Measurement</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_unit_of_measurement" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_unit_of_measurement" style="width:220px; height:35px" class="form-control" id="assert_unit_of_measurement">
				  <option value="select"></option>
				  <option value="nos">Nos</option>
				  <option value="packs">Packs</option>
				  <option value="kg">Kg</option>
				  <option value="g">g</option>
				  <option value="dozen">Dozen</option>
				  </select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_milage" id="preinput">Milage of Maintenance</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_milage" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_milage" id="inputid">
			</div>
			
			

			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_capacity" id="preinput">Capacity</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_capacity" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_capacity" id="inputid">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="expected_time" id="preinput">Expected time of Consuming</label>
			</div>
			<div class="col-sm-1">
				<label for="expected_time" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="date" class="form-control" style="width:220px; height:35px" name="expected_time" id="inputid">
			</div>
			

			
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_location" id="preinput">Location</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_location" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			<!--
				  <select name="assert_ownership" id="assert_ownership">
				  <option value="select"></option>
				  <option value="own">Own</option>
				  <option value="hired">Hired</option>
				  <option value="other">Other</option>
				  </select>
			-->
				  
				  <?php
				  
				  ?>
				  <select name="assert_location" style="width:220px; height:35px" class="form-control" id="failure">
					  <option value="select"></option>
					  <?php 
						while($row = $result_loca->fetch_assoc()) {
					  ?>
						<option value="<?php echo $row['location_id'];?>">
						<?php echo $row['location_name'];?></option>
					  <?php
						}
					  ?>
					  
					</select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="description" id="preinput">Description</label>
			</div>
			<div class="col-sm-1">
				<label for="description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="description" id="inputid">
			</div>
			
	  </div>
	  
	  <div class="row pt-2">
	  		<div class="col-sm-2" id="div1">
			<label for="assert_warranty_period" id="preinput">Warranty Period</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_warranty_period" id="preinput">:</label>
			</div>
			<div class="col-sm-2" id="div1">
				<input type="text" class="form-control" name="assert_warranty_period" style="width:220px; height:35px" id="assert_warranty_period" id="inputid">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="instructions" id="preinput">Instructions of Maintenance</label>
			</div>
			<div class="col-sm-1">
				<label for="instructions" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="instructions" id="inputid">
			</div>
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_invoiced_amount" id="preinput">Invoiced Amount</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_invoiced_amount" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px" name="assert_invoiced_amount" id="inputid">
			</div>
			

			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2" id="div1">
				<label for="completion_date" id="preinput">Date of Completion</label>
			</div>
			<div class="col-sm-1">
				<label for="completion_date" id="preinput">:</label>
			</div>
			<div class="col-sm-2" id="div1">
				<input type="date" class="form-control" style="width:220px; height:35px" name="completion_date" id="inputid" id="completion_date">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2"></div>
			
			<div class="col-sm-1">				
				<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;">Save</button>
			</div>
			
			<div class="col-sm-2"></div>
				
	  </div>
  
</div>

</form>
<?php include 'template/footer.php'; ?>