  <?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var assert_type = $('#assert_type').val(); 
						//alert(assert_type);
						var assert_category = $('#assert_category').val();
						var assert_name = $('#assert_name').val();
						var assert_item_code = $('#assert_item_code').val(); 
						var assert_brand = $('#assert_brand').val();
						var assert_model = $('#assert_model').val();
						var assert_location = $('#assert_location').val(); 
						//var completion_date = $('#completion_date').val();
						//var warranty = $('#assert_warranty_period').val();
						var click='TRUE';
			
			
			//if(assert_type !="" && assert_category !="" && assert_name!="" && item_code!="" && brand!="" && model!="" && location!=""){
			//alert($("#myform input").serialize());
			url='a_master_view.php?click=true&assert_type='+assert_type+'&assert_category='+assert_category+'&assert_location='+assert_location+'';
			//alert(url);
				
			$.ajax({
				url:'a_master_view.php?click=true&assert_type='+assert_type+'&assert_category='+assert_category+'&assert_location='+assert_location+'',
				type: 'GET',
				data: '&assert_type='+assert_type+'&assert_category='+assert_category+'&assert_name='+assert_name+'&assert_item_code='+assert_item_code+'&assert_brand='+assert_brand+'&assert_model='+assert_model+'&assert_location='+assert_location+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
	
	
					function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'assert_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  //alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }		

</script>



<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">
							<div class="container mt-5">
							  <div class="row pt-6"><center>
								</div><br>

							<div class="row pt-2">
										<div class="col-sm-2">
										    <label for="assert_type" id="preinput">Assert Type</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_type" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											
											  <select name="assert_type" id="assert_type" style="width:170px; height:35px;" class="form-control">
												  <option value="0">select</option>
												  <option value="fixed">Fixed</option>
												  <option value="movable">Movable</option>
												  <option value="other">Other</option>
											  </select>
										</div>
										
										<div class="col-sm-2">
										    <label for="assert_item_code" id="preinput">Item Code</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_item_code" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="assert_item_code" id="assert_item_code" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										    <label for="assert_category" id="preinput">Assert Category</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_category" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											
											  <select name="assert_category" id="assert_category" style="width:170px; height:35px" class="form-control">
													  <option value="0">select</option>
													  <option value="COSMR">Consumer</option>
													  <option value="ECL">Electrical</option>
													  <option value="ECC">Electronic</option>
													  <option value="FURNITURE">Furniture</option>
													  <option value="MNT">Maintenance</option>
													  <option value="MOTOR">Motor</option>
													  <option value="RMVB">Removable</option>
													  <option value="OTHER">Other</option>
											  </select>
											  
										</div>
										
										<div class="col-sm-2">
										    <label for="assert_brand" id="preinput">Brand</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_brand" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="assert_brand" id="assert_brand" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										    <label for="assert_name" id="preinput">Assert Name</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_name" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" style="width:170px; height:35px" class="form-control" name="assert_name" id="assert_name" >
										</div>
										
										<div class="col-sm-2">
										    <label for="assert_model" id="preinput">Model</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_model" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="assert_model" id="assert_model" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										    <label for="assert_location" id="preinput">Location</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_loction" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											  <select name="assert_location" id="assert_location" style="width:170px; height:35px" class="form-control">
											  <option value="0">select</option>
											  <option value="3">CGR</option>
											  <option value="1">First floor A side</option>
											  <option value="2">First floor B side</option>
											  <option value="4">Ground floor A side</option>
											  <option value="5">Ground floor B side</option>
											  </select>
										</div>					
							</div><br>

							<div class="row pt-2">
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
										
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
												
												<div class="col-sm-2"></div>
												
												<div class="col-sm-1" class="div1">
													<button name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
												</div>
												<div class="col-sm-2"></div>
										</div>
							</div>

</div>

</div>
<!-- </form> -->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>

