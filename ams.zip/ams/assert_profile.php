<?php include 'template/header.php'; ?>

<form>

<div class="container mt-5">
  <div class="row pt-6"><center>
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black">Assert Profile</font></label></b></center>
	</div><br>
	
	<div class="row pt-2">
			<div class="col-sm-2">
			  <label for="type" id="preinput">Assert Type</label>
			</div>
			<div class="col-sm-1">
				<label for="type" id="preinput">:</label>
			</div>
			 <div class="col-sm-2">
				<select name="type" id="type" style="width:220px; height:35px;"  class="form-control">
				<option value="selectuser"></option>
				<option value="fixed">Fixed</option>
				<option value="movable">Movable</option>
				<option value="other">Other</option>
				</select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="amount" id="preinput">Amount of Insured</label>
			</div>
			<div class="col-sm-1">
					<label for="amount" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="amount" id="inputid" >
			</div> 
			
	</div>
	
	<div class="row pt-2">
			<div class="col-sm-3">
			  <label for="category" id="preinput">Assert Category</label>
			  </div>
			 <div class="col-sm-2">
				<select name="category" id="category" style="width:220px; height:35px" class="form-control">
				<option value="selectcat"></option>
				<option value="consumer">Consumer</option>
				<option value="electrical">Electrical</option>
				<option value="electronic">Electronic</option>
				<option value="furniture">Furniture</option>
				<option value="maintenance">Maintenance</option>
				<option value="motor">Motor</option>
				<option value="removable">removable</option>
				<option value="other">Other</option>
				</select>
			</div>
			
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="responsible" id="preinput">Responsible Division</label>
			</div>
			<div class="col-sm-1">
					<label for="responsible" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="responsible" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="aname" id="preinput">Assert Name</label>
			</div>
			<div class="col-sm-1">
					<label for="aname" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="aname" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="supplier" id="preinput">Supplier</label>
			</div>
			<div class="col-sm-1">
					<label for="supplier" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="supplier" id="inputid" >
			</div>
	</div>
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="itemcode" id="preinput">Item Code</label>
			</div>
			<div class="col-sm-1">
					<label for="itemcode" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="itemcode" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="supplieraddress" id="preinput">Supplier Address</label>
			</div>
			<div class="col-sm-1">
					<label for="supplieraddress" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="supplieraddress" id="inputid" >
			</div>
	</div>
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="brand" id="preinput">Brand</label>
			</div>
			<div class="col-sm-1">
					<label for="brand" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="brand" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="pno" id="preinput">Procument No.</label>
			</div>
			<div class="col-sm-1">
					<label for="pno" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="pno" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="model" id="preinput">Model</label>
			</div>
			<div class="col-sm-1">
					<label for="model" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="model" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="sagreement" id="preinput">Survice agreement</label>
			</div>
			<div class="col-sm-1">
					<label for="sagreement" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="sagreement" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="unit" id="preinput">Unit of Measurement</label>
			</div>
			<div class="col-sm-1">
					<label for="unit" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="unit" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="frequency" id="preinput">Frequency of Maintenance</label>
			</div>
			<div class="col-sm-1">
					<label for="frequency" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="frequency" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="capacity" id="preinput">Capacity</label>
			</div>
			<div class="col-sm-1">
					<label for="capacity" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="capacity" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="milage" id="preinput">Milage of Maintenance</label>
			</div>
			<div class="col-sm-1">
					<label for="milage" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="milage" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="location" id="preinput">Location</label>
			</div>
			<div class="col-sm-1">
					<label for="location" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="location" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="etime" id="preinput">Expected Time</label>
			</div>
			<div class="col-sm-1">
					<label for="etime" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="time" class="form-control" style="width:220px; height:35px;" name="etime" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="date" id="preinput">Date of Complete</label>
			</div>
			<div class="col-sm-1">
					<label for="date" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="date" class="form-control" style="width:220px; height:35px;" name="date" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="description" id="preinput">Description</label>
			</div>
			<div class="col-sm-1">
					<label for="description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="description" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="invoice" id="preinput">Invoiced Amount</label>
			</div>
			<div class="col-sm-1">
					<label for="invoice" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="invoice" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="imain" id="preinput">Instructions for Maintenance</label>
			</div>
			<div class="col-sm-1">
					<label for="imain" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="imain" id="inputid" >
			</div>
	</div>
	
	<div class="row pt-2">
						
			<div class="col-sm-2">
				<label for="warranty" id="preinput">Warranty Period</label>
			</div>
			<div class="col-sm-1">
					<label for="warranty" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:220px; height:35px;" name="warranty" id="inputid" >
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
			</div>
			<div class="col-sm-1">
				<br><br><br>
				<button type="submit" name="add" style="background-color:gray; width:100px; height:40px;">Save</button>
			<div class="col-sm-2">
			</div>
	</div>
	
		
</form>
<?php include 'template/footer.php'; ?>