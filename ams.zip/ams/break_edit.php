<!--<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>	
  -->
 <?php
 include 'template/header.php';
//echo 'jkjkjk '.$_SESSION['user_level'].'...........mmaadddddddd ';
	if((isset($_SESSION['user_level'])) && (($_SESSION['user_level']=='1') || ($_SESSION['user_level']=='2')))
	{	
	include 'db_connect.php';
	
	$breakdown_id = $_GET['breakdown_id'];
	
	$edit = "SELECT 
	         *FROM 
			    tbl_breakdown 
			  WHERE 
			   `breakdown_id`='".$_GET['breakdown_id']."'";	

    $result_break_ed = $conn->query($edit);
	
	$row = mysqli_fetch_array($result_break_ed);
	
	if(isset($_POST['update']))
					{	 
						    
							$assert_item_code = $_POST['assert_item_code'];
							$b_type_failure = $_POST['b_type_failure'];
							$b_diagnosed_date = $_POST['b_diagnosed_date'];
							$b_diagnosed_time = $_POST['b_diagnosed_time'];
							$b_condition = $_POST['b_condition'];
							$b_action = $_POST['b_action'];
							$b_backup = $_POST['b_backup'];
							$b_recommendation = $_POST['b_recommendation'];
							$b_description = $_POST['b_description'];
							
							
							$new1 = "UPDATE 
									tbl_breakdown 
									SET 
											assert_item_code = '$assert_item_code', b_type_failure='$b_type_failure', b_diagnosed_date='$b_diagnosed_date', b_diagnosed_time='$b_diagnosed_time', b_condition='$b_condition',
											b_action='$b_action', b_backup='$b_backup', b_recommendation='$b_recommendation', b_description='$b_description'
									WHERE 
											breakdown_id = '$breakdown_id'";
							
  

                        if (mysqli_query($conn, $new1)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $new1 . "
					" . mysqli_error($conn);
						 }
						 

                if($new1)
					{
						mysqli_close($conn); // Close connection
						header("location:breakdown_view.php"); // redirects to all records page
						exit;
					}
					else
					{
						echo mysqli_error();
					}    							 
}
?>		
			

<form action="" method="POST">


<div class="container mt-5">
 
  <div class="row pt-2">
   <div class="col-sm-5"><font size="6px"><b>Add Failure Notice</b></font></div>
  </div><br>
  
  <div class="row pt-2">
	<div class="col-sm-2">
		<label for="assert_item_code" id="preinput">Item No</label>
	</div>
	<div class="col-sm-1">
		<label for="assert_item_code" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
		<input type="text" class="form-control" style="width:310px; height:40px;"  name="assert_item_code" id="inputid" value="<?php echo $row['assert_item_code']; ?>" >
		
	</div>
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-7">
	<input type="text" style="width:700px; height:40px;" id="inputid" id="keyword"/>
	</div>
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_type_failure" id="preinput">Type of Failure</label>
	</div>
	<div class="col-sm-1">
		<label for="b_type_failure" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
		  <select name="b_type_failure" id="b_type_failure" style="width:310px; height:40px;" class="form-control" value="<?php echo $row['b_type_failure'] ?>">
		  <option value="select"<?php if($row['b_type_failure']== 'select'){ echo 'selected'; }?>></option>
		  <option value="minor"<?php if($row['b_type_failure']== 'minor'){ echo 'selected'; }?>>Minor</option>
		  <option value="major"<?php if($row['b_type_failure']== 'major'){ echo 'selected'; }?>>Major</option>
		  <option value="accident"<?php if($row['b_type_failure']== 'accident'){ echo 'selected'; }?>>Accident</option>
		  </select>
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_diagnosed_date" id="preinput">Date/ Time of Diagnosed</label>
	</div>
	<div class="col-sm-1">
		<label for="b_diagnosed_date" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="date" class="form-control" style="width:310px; height:40px;" name="b_diagnosed_date" id="inputid" value="<?php echo $row['b_diagnosed_date']; ?>">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	</div>
	<div class="col-sm-1">
	</div>
	<div class="col-sm-3">
	<input type="time" class="form-control" style="width:310px; height:40px;" name="b_diagnosed_time" id="inputid" value="<?php echo $row['b_diagnosed_time']; ?>">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_condition" id="preinput">Present Condition</label>
	</div>
	<div class="col-sm-1">
		<label for="b_condition" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_condition" id="inputid" value="<?php echo $row['b_condition']; ?>">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_action" id="preinput">Action Taken</label>
	</div>
	<div class="col-sm-1">
		<label for="b_action" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_action" id="inputid" value="<?php echo $row['b_action']; ?>">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_backup" id="preinput">Backup Procedure</label>
	</div>
	<div class="col-sm-1">
		<label for="b_backup" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_backup" id="inputid" value="<?php echo $row['b_backup']; ?>">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_recommendation" id="preinput">Recommendation of Supervisor</label>
	</div>
	<div class="col-sm-1">
		<label for="b_recommendation" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_recommendation" id="inputid" value="<?php echo $row['b_recommendation']; ?>">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_description" id="preinput">Description</label>
	</div>
	<div class="col-sm-1">
		<label for="b_description" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_description" id="inputid" value="<?php echo $row['b_description']; ?>">
	<br><br>
	<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;">Save</button>
	</div> 
  </div>
  
  
  
</div>

</form>

<?php
	}
	else{
		echo "You do not have access to this page... Please contact admin or manager";
		?>
		<button type="home" name="home" style="background-color:gray"><a href="home_page.php">Home</a></button>
		<button type="back" name="back" style="background-color:gray"><a href="user_view.php">Back</a></button>
		<?php
	}
	
  ?>
</body>
</html>