
	<?php 
			session_start();
			include 'db_connect.php';
			if(isset ($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';
					$assert_item_code = $_GET['assert_item_code'];
					$b_type_failure = $_GET['b_type_failure'];
					$b_diagnosed_date = $_GET['b_diagnosed_date']; 
					$b_diagnosed_time = $_GET['b_diagnosed_time'];
					
					
					
					$filter = "1=1 ";
					
					if(isset($_GET['breakdown_id']) && ($_GET['breakdown_id']!=''))
					{
						$filter .= " AND `breakdown_id` LIKE '%".$_GET['breakdown_id']."%'";
					}
					
					if(isset($_GET['assert_item_code']) && ($_GET['assert_item_code']!=''))
					{
						$filter .= " AND `assert_item_code` LIKE '%".$_GET['assert_item_code']."%'";
					}
					
					if(isset($_GET['b_type_failure']) && ($_GET['b_type_failure']!='0'))
					{
						$filter .= " AND `b_type_failure` = '".$_GET['b_type_failure']."'";
					}
					
					
					if(isset($_GET['b_diagnosed_date']) && ($_GET['b_diagnosed_date']!=''))
					{
						$filter .= " AND `b_diagnosed_date` LIKE '%".$_GET['b_diagnosed_date']."%'";
					}	
					
					if(isset($_GET['b_diagnosed_time']) && ($_GET['b_diagnosed_time']!=''))
					{
						$filter .= " AND `b_diagnosed_time` LIKE '%".$_GET['b_diagnosed_time']."%'";
					}	
					
					if(isset($_GET['b_condition']) && ($_GET['b_condition']!=''))
					{
						$filter .= " AND `b_condition` LIKE '%".$_GET['b_condition']."%'";
					}
					
					if(isset($_GET['b_action']) && ($_GET['b_action']!=''))
					{
						$filter .= " AND `b_action` LIKE '%".$_GET['b_action']."%'";
					}     
					
					
					if(isset($_GET['b_recommendation']) && ($_GET['b_recommendation']!=''))
					{
						$filter .= " AND `b_recommendation` LIKE '%".$_GET['b_recommendation']."%'";
					}
						
					
					$view = "SELECT 
									`breakdown_id`,`assert_item_code`,`b_type_failure`,`b_diagnosed_date`,`b_diagnosed_time`,`b_condition`,`b_action`,`b_recommendation`
								FROM 
									tbl_breakdown 
								WHERE 
									$filter";
				    //echo '2222';
				    
					$result = $conn->query($view);

							
			}
			else{
				echo "Invalid Calling Method!";
				
			}
        //echo 'mklslkfjsafj';
			
					
?>
			
<div class="container">
   <br/>
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading"></div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Item No</th>
								<th>Type of failure</th>
								<th>Diagnosed Date</th>
								<th>Diagnosed Time</th>
								<th>Condition</th>
								<th>Action</th>
								<th>Recommendation</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
								//echo 'ggggg';
						?>
						
							<tr>
							    <td><?php echo $row['breakdown_id']; ?></td>
								<td><?php echo $row['assert_item_code']; ?></td>
								<td><?php echo $row['b_type_failure']; ?></td>
								<td><?php echo $row['b_diagnosed_date']; ?></td>
								<td><?php echo $row['b_diagnosed_time']; ?></td>
								<td><?php echo $row['b_condition']; ?></td>
								<td><?php echo $row['b_action']; ?></td>
								<td><?php echo $row['b_recommendation']; ?></td>
								
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['breakdown_id'].'" id="edit"><a href="break_edit.php?breakdown_id=<?php echo $row['breakdown_id'];?>"> Edit </a></button>
                                <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['breakdown_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['breakdown_id'].'" id="delete"> Delete </button></td>
                            <?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
							
							
							</tr>
						<?php
							}
						?>
						</tbody>
							
						</table>
					</div>
					</div>
				</div>
	</hr>

</div>
