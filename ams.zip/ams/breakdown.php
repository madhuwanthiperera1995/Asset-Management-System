<?php include 'template/header.php'; ?>
  
    <script>
			/*$(function() {
            $( "#fill" ).autocomplete({
                source: function( request, response ) {
					
                    $.ajax({
                        url: "breakdown_autofill.php",
                        dataType: "jsonp",
                        data: {
                            q: request.term
                        },
                        success: function( data ) {
                            response( data );
                        }
                    });
                },
            });
        });  */
		
				/*$(document).ready(function(){
					$("#inputid").keyup(function(){
						$.ajax({
						type: "POST",
						url: "assert_ajax.php",
						data:'keyword='+$(this).val(),
						beforeSend: function(){
							$("#inputid").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
						},
						success: function(data){
							$("#suggesstion_box").show();
							$("#suggesstion_box").html(data);
							$("#inputid").css("background","#FFF");
						}
						});
					});
				}); */

			    /*
			     $(document).ready(function() {
					$('#searchbox').keyup(function() { // upon every key up when user is typing
						$('#suggestions').html(''); // clear if any previous suggestions

						var input = $(this).val();

						$.getJSON( // sending a GET request via AJAX expecting a JSON response
							'assert_ajax.php', // to this URL where the PHP file is
							{
								searchQuery: input // with the text user typed in
							},
							function(data) { // upon receiving a response
								$(data).each(function() { // iterate through the suggestions data received as JSON
									var suggestion = '<option keyword=' + this + '>'; // create an <option> element with the each suggestion
									$('#suggestions').append(suggestion); // and append it to the suggestions <datalist>
								});
							}
						});
					});
				});*/
	</script>
  
  <?php
	include 'db_connect.php';
			
					if(isset($_POST['save']))
					{	 
						    
							$assert_item_code = $_POST['assert_item_code'];
							$b_type_failure = $_POST['b_type_failure'];
							$b_diagnosed_date = $_POST['b_diagnosed_date'];
							$b_diagnosed_time = $_POST['b_diagnosed_time'];
							$b_condition = $_POST['b_condition'];
							$b_action = $_POST['b_action'];
							$b_backup = $_POST['b_backup'];
							$b_recommendation = $_POST['b_recommendation'];
							$b_description = $_POST['b_description'];
							
							
							$sql = "INSERT INTO 
							           tbl_breakdown
									   (assert_item_code,b_type_failure,b_diagnosed_date,b_diagnosed_time,b_condition,b_action,b_backup,
							            b_recommendation,b_description,b_active_status)
							
							VALUES ( 
							'".$assert_item_code."','".$b_type_failure."','".$b_diagnosed_date."','".$b_diagnosed_time."','".$b_condition."','".$b_action."','".$b_backup."',
							'".$b_recommendation."','".$b_description."',1)";
							
							//$_SESSION['breakdown_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
			?>
			

<form action="" method="POST">


<div class="container mt-5">
 
  <div class="row pt-2">
   <div class="col-sm-5"><font size="6px"><b>Add Failure Notice</b></font></div>
  </div><br>
  
  <div class="row pt-2">
	<div class="col-sm-2">
		<label for="assert_item_code" id="preinput">Item No</label>
	</div>
	<div class="col-sm-1">
		<label for="assert_item_code" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
		<input type="text" class="form-control" style="width:310px; height:40px;" list="suggesstion_box" name="assert_item_code" id="inputid" >
		<div id="suggesstion_box"></div>
	</div>
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-7">
	<input type="text" style="width:700px; height:40px;" id="inputid" id="keyword"/>
	</div>
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_type_failure" id="preinput">Type of Failure</label>
	</div>
	<div class="col-sm-1">
		<label for="b_type_failure" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
		  <select name="b_type_failure" id="b_type_failure" style="width:310px; height:40px;" class="form-control">
		  <option value="select"></option>
		  <option value="minor">Minor</option>
		  <option value="major">Major</option>
		  <option value="accident">Accident</option>
		  </select>
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_diagnosed_date" id="preinput">Date/ Time of Diagnosed</label>
	</div>
	<div class="col-sm-1">
		<label for="b_diagnosed_date" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="date" class="form-control" style="width:310px; height:40px;" name="b_diagnosed_date" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	</div>
	<div class="col-sm-1">
	</div>
	<div class="col-sm-3">
	<input type="time" class="form-control" style="width:310px; height:40px;" name="b_diagnosed_time" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_condition" id="preinput">Present Condition</label>
	</div>
	<div class="col-sm-1">
		<label for="b_condition" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_condition" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_action" id="preinput">Action Taken</label>
	</div>
	<div class="col-sm-1">
		<label for="b_action" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_action" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_backup" id="preinput">Backup Procedure</label>
	</div>
	<div class="col-sm-1">
		<label for="b_backup" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_backup" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_recommendation" id="preinput">Recommendation of Supervisor</label>
	</div>
	<div class="col-sm-1">
		<label for="b_recommendation" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_recommendation" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="b_description" id="preinput">Description</label>
	</div>
	<div class="col-sm-1">
		<label for="b_description" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="b_description" id="inputid">
	<br><br>
	<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;">Save</button>
	</div> 
  </div>
  
  
  
</div>

</form>
<?php include 'template/footer.php'; ?>