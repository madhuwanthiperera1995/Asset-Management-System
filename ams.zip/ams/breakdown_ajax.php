<?php 
			
	include 'db_connect.php';
			
		if((isset($_POST['del_id'])) && ($_POST['del_id']>0)){
				$delete ="UPDATE 
							tbl_breakdown 
						  SET
							`b_active_status` = 0
						  WHERE
							`breakdown_id`='".$_POST['del_id']."'
							";
				
				$result_del = $conn->query($delete);
		}
?>