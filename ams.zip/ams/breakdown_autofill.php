<?php 

	include 'db_connect.php';
			
	require_once ('breakdown.php');

    $q=$_REQUEST["q"]; 
	
			$sql="SELECT 
					`assert_brand`,`assert_model`,`assert_name`,`assert_responsible_division`,`completion_date`,`assert_warranty_period`,
					`assert_amount_insured` 
				  FROM 
					tbl_assert_master_system  
				  WHERE 
					 `assert_id` 
				  LIKE 
					 '%$q%'";
					 
			echo $sql;
			 
    $result = mysql_query($sql);

    $json=array();

    while($row = mysql_fetch_array($result)) {
      array_push($json, $row['assert_brand'], $row['assert_model'], $row['assert_name'], $row['assert_responsible_division'], $row['completion_date'], 
	             $row['assert_warranty_period'], $row['assert_amount_insured']);
    }

    echo json_encode($json);
			
?>