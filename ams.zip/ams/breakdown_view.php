  <?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						
						var assert_item_code = $('#assert_item_code').val(); 
						var b_type_failure = $('#b_type_failure').val();
						var b_diagnosed_date = $('#b_diagnosed_date').val();
						var b_diagnosed_time = $('#b_diagnosed_time').val(); 
						var click='TRUE';
			
			
			
			url='break_view.php?click=true&b_type_failure='+b_type_failure+'';
			//alert(url);
				
			$.ajax({
				url:'break_view.php?click=true&b_type_failure='+b_type_failure+'',
				type: 'GET',
				data: '&assert_item_code='+assert_item_code+'&b_type_failure='+b_type_failure+'&b_diagnosed_date='+b_diagnosed_date+'&b_diagnosed_time='+b_diagnosed_time+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
	
	
					function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'breakdown_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  //alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }		

					

</script>



<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">
							<div class="container mt-5">
							  <div class="row pt-6"><center>
								</div><br>

							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="assert_item_code" id="preinput">ID</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_item_code" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											
											  <input type="text" class="form-control" style="width:170px; height:35px" name="assert_item_code" id="assert_item_code" >
										</div>
										
							</div>

							<div class="row pt-2">
							            <div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="b_type_failure" id="preinput">Type of failure</label>
										</div>
										<div class="col-sm-1">
											<label for="b_type_failure" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											
											  <select name="b_type_failure" id="b_type_failure" style="width:170px; height:35px" class="form-control">
													  <option value="0">select</option>
													  <option value="minor">Minor</option>
													  <option value="major">Major</option>
													  <option value="accident">Accident</option>
											  </select>
											  
										</div>
										
							</div>

							<div class="row pt-2">
							            <div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="b_diagnosed_date" id="preinput">Date</label>
										</div>
										<div class="col-sm-1">
											<label for="b_diagnosed_date" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="date" style="width:170px; height:35px" class="form-control" name="b_diagnosed_date" id="b_diagnosed_date" >
										</div>
							</div>

							<div class="row pt-2">
							            <div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="b_diagnosed_time" id="preinput">Time</label>
										</div>
										<div class="col-sm-1">
											<label for="b_diagnosed_time" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											  <input type="time" style="width:170px; height:35px" class="form-control" name="b_diagnosed_time" id="b_diagnosed_time" >
										</div>					
							</div><br>

							<div class="row pt-2">
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
										
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
												
												<div class="col-sm-2"></div>
												
												<div class="col-sm-1" class="div1">
													<button name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
												</div>
												<div class="col-sm-2"></div>
										</div>
							</div>

</div>

</div>
<!-- </form> -->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>

