<?php 
			
	include 'db_connect.php';
			
		if((isset($_POST['del_id'])) && ($_POST['del_id']>0)){
				$delete ="UPDATE 
							tbl_sys_assert_category 
						  SET
							`sys_category_active_status` = 0
						  WHERE
							`sys_assert_cat_id`='".$_POST['del_id']."'
							";
				
				$result_del = $conn->query($delete);
		}
?>