<?php include 'template/header.php'; ?>

    <?php
	include 'db_connect.php';
	
	$assert = "SELECT `assert_name`,`assert_code` FROM tbl_asser_category WHERE `assert_active_status` = 1 ORDER BY `assert_name` asc";
	
	$result_ass = $conn->query($assert);
	
	?>
	
  
  <?php
					if(isset($_POST['save']))
					{	 
						    
							$checklist_date = $_POST['checklist_date'];
							$checklist_item_cat = $_POST['checklist_item_cat'];
							$checklist_no_of_item = $_POST['checklist_no_of_item'];
							$checklist_cat = $_POST['checklist_cat'];
							$time = date("d-m-Y")."-".time();
							$checklist_file = $_FILES['checklist_file']['name'];
							$checklist_file = $time."-".$checklist_file ;
							
							
							$sql = "INSERT INTO tbl_new_checklist(
									checklist_date,checklist_item_cat,checklist_no_of_item,checklist_cat,checklist_file,checklist_time,checklist_active_status)
							
							VALUES ( 
							'".$checklist_date."','".$checklist_item_cat."','".$checklist_no_of_item."','".$checklist_cat."', '".$checklist_file."',NOW(),1)";
							
							//$_SESSION['checklist_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
			?>
			
			<?php 
				if(isset($_POST['save'])){
					if($_FILES['checklist_file']['name']){

				 
						// here is the current date time timestamp
						$time = date("d-m-Y")."-".time();
				 
						// here we set it to the file name
						$fileName = $_FILES['checklist_file']['name'];
						$fileName = $time."-".$fileName ;
				         
						// upload that image into the directory name: document
						move_uploaded_file($_FILES['checklist_file']['tmp_name'], "document/".$fileName);
						$file="document/".$_FILES['checklist_file']['name'];
				 
					}else{
						echo "Something went wrong";
					}
				} 
            ?>


<form action="" method="POST" enctype="multipart/form-data">

<div class="container mt-5">
  <div class="row pt-6"><center>
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black">Daily Checklist</font></label></b></center>
	</div><br>

		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2">
				<label for="checklist_date" id="preinput">Date</label>
			</div>
			<div class="col-sm-1">
			    <label for="checklist_date" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			    <input type="date" class="form-control" style="width:220px; height:35px;"  name="checklist_date" id="inputid">
			</div> 
		</div>
		
		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2">
				<label for="checklist_item_cat" id="preinput" >Item Category</label>
			</div>
			<div class="col-sm-1">
			    <label for="checklist_item_cat" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			 	<!--<select name="checklist_item_cat" id="checklist_item_cat" style="width:220px; height:35px" class="form-control">
				<option value="0">select</option>
				<option value="consumer">Consumer</option>
				<option value="electrical">Electrical</option>
				<option value="electronic">Electronic</option>
				<option value="furniture">Furniture</option>
				<option value="maintenance">Maintenance</option>
				<option value="motor">Motor</option>
				<option value="removable">Removable</option>
				<option value="other">Other</option>
				</select>-->
				
				<?php
				  
				  ?>
				  <select name="checklist_item_cat" style="width:220px; height:35px" class="form-control" id="failure">
					  <option value="select"></option>
					  <?php 
						while($row = $result_ass->fetch_assoc()) {
					  ?>
						<option value="<?php echo $row['assert_code'];?>">
						<?php echo $row['assert_name'];?></option>
					  <?php
						}
					  ?>
					  
				</select>
			
				
			</div> 
		</div>
		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2">
				<label for="checklist_no_of_item" id="preinput">No. of Functioning item</label>
			</div>
			<div class="col-sm-1">
			    <label for="checklist_no_of_item" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			    <input type="text" class="form-control" style="width:220px; height:35px;"  name="checklist_no_of_item" id="inputid">
			</div> 
		</div>
		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2">
				<label for="checklist_cat" id="preinput" >Checklist Category</label>
			</div>
			<div class="col-sm-1">
			    <label for="checklist_cat" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			 	<select name="checklist_cat" id="checklist_cat" style="width:220px; height:35px" class="form-control" id="inputid">
						<option value="0">Select</option>
						<option value="cleaning">Cleaning</option>
						<option value="TV">TV</option>
						<option value="CCTV">CCTV</option>
						<option value="UPS">UPS</option>
						<option value="telephone">Telephone</option>
						<option value="park and ride">Park and ride</option>
						<option value="PA rack">PA rack</option>
						<option value="network crack">Network crack</option>
						<option value="other">Other</option>
				</select>
				
			</div> 
		</div>
		
		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2">
				<label for="checklist_file" id="preinput">File</label>
			</div>
			<div class="col-sm-1">
			    <label for="checklist_file" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			    <input type="file" id="checklist_file" name="checklist_file"  id="inputid" accept=".xls,.xlsx" value="checklist_file"/><br><br><br>
				<button type="submit" id="save" name="save" style="background-color:gray; width:100px; height:40px;" value="upload">Save</button>
			</div> 
		</div>
		
</div>

</form>

<?php include 'template/footer.php'; ?>