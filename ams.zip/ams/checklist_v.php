
        <?php 
			include 'db_connect.php';
			if(isset ($_GET['click'])){
				$action = $_GET['click'];
				
                    //echo 'alert 11';
					
					$checklist_date = $_GET['checklist_date'];
					$checklist_cat = $_GET['checklist_cat'];
					
					$filter = "1=1 ";
					
					if(isset($_GET['new_checklist_id']) && ($_GET['new_checklist_id']!=''))
					{
						$filter .= " AND `new_checklist_id` LIKE '%".$_GET['new_checklist_id']."%'";
					}
					
					if(isset($_GET['checklist_date']) && ($_GET['checklist_date']!=''))
					{
						$filter .= " AND `checklist_date` LIKE '%".$_GET['checklist_date']."%'";
					}
					
					if(isset($_GET['checklist_cat']) && ($_GET['checklist_cat']!='0'))
					{
						$filter .= " AND `checklist_cat` = '".$_GET['checklist_cat']."'";
					}
					
					if(isset($_GET['checklist_item_cat']) && ($_GET['checklist_item_cat']!=''))
					{
						$filter .= " AND `checklist_item_cat` LIKE '%".$_GET['checklist_item_cat']."%'";
					}
					
					if(isset($_GET['checklist_file']) && ($_GET['checklist_file']!=''))
					{
						$filter .= " AND `checklist_file` = '".$_GET['checklist_file']."'";
					}
					
					
					$view = "SELECT 
									`new_checklist_id`,`checklist_date`,`checklist_cat`,`checklist_item_cat`,`checklist_file`
								FROM 
									tbl_new_checklist 
								WHERE 
									$filter";
				    //echo '2222';
				    
					$result = $conn->query($view);

							
			}
			else{
				echo "Invalid Calling Method!";
				
			}
        //echo 'mklslkfjsafj';
			
					
        ?>

            <?php 
				if(isset($_POST['download'])){
					if($_FILES['checklist_file']['name']){

				 
						// here is the current date time timestamp
						$time = date("d-m-Y")."-".time();
				 
						// here we set it to the file name
						$fileName = $_FILES['checklist_file']['name'];
						$fileName = $time."-".$fileName ;
				         
						// upload that image into the directory name: document
						move_uploaded_file($_FILES['checklist_file']['tmp_name'], "document/".$fileName);
						$file="document/".$_FILES['checklist_file']['name'];
				 
					}else{
						echo "Something went wrong";
					}
				} 
            ?>
			


			
<div class="container">
   <br/>
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading"></div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Date</th>
								<th>Checklist Category</th>
								<th>Item Category</th>
								<th>File</th>
								<th>Download</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
								
						?>
						
						
							<tr>
							    <td><?php echo $row['new_checklist_id']; ?></td>
								<td><?php echo $row['checklist_date']; ?></td>
								<td><?php echo $row['checklist_cat']; ?></td>
								<td><?php echo $row['checklist_item_cat']; ?></td>
								<td><?php echo $row['checklist_file']; ?></td>
								<td><button type="button" name="download" id="download" class="btn btn-warning bt-xs download">
								<a href="document/<?php
								                     echo $row['checklist_file']; 
												   ?> " target="_BLANK"> View File </a></button></td>
							</tr>
							
						<?php
							}
							
						?>
						</tbody>
							
						</table>
					</div>
					</div>
				</div>
	</hr>

</div>
