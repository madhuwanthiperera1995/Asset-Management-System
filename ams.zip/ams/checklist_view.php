<?php include 'template/header.php'; ?>

      <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var checklist_date = $('#checklist_date').val(); 
						var checklist_cat = $('#checklist_cat').val(); 
						var click='TRUE';
			
			
			url='checklist_v.php?click=true&checklist_date='+checklist_date+'&checklist_cat='+checklist_cat+'';
			//alert(url);
				
			$.ajax({
				url:'checklist_v.php?click=true&checklist_date='+checklist_date+'&checklist_cat='+checklist_cat+'',
				type: 'GET',
				data: '&checklist_date='+checklist_date+'&checklist_cat='+checklist_cat+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
	
				function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'other_asset_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  //alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }	

</script>

<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">
  <div class="row pt-6"><center>
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black">Daily Checklist</font></label></b></center>
	</div><br>

		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2">
				<label for="checklist_date" id="preinput">Date</label>
			</div>
			<div class="col-sm-1">
			    <label for="checklist_date" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
			    <input type="date" class="form-control" style="width:220px; height:35px;"  name="checklist_date" id="checklist_date">
			</div> 
		</div>
		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2">
				<label for="checklist_cat" id="preinput" >Checklist Category</label>
			</div>
			<div class="col-sm-1">
			    <label for="checklist_cat" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			 	<select name="checklist_cat" id="checklist_cat" style="width:220px; height:35px" class="form-control" class="div1">
						<option value="0">Select</option>
						<option value="cleaning">Cleaning</option>
						<option value="TV">TV</option>
						<option value="CCTV">CCTV</option>
						<option value="UPS">UPS</option>
						<option value="telephone">Telephone</option>
						<option value="park and ride">Park and ride</option>
						<option value="PA rack">PA rack</option>
						<option value="network crack">Network crack</option>
						<option value="other">Other</option>
				</select>
				
			</div> 
		</div><br>
		
		
		<div class="row pt-2">

			<div class="col-sm-3"></div>
			
			<div class="col-sm-2"></div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2" class="div1">
				<button name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
			</div> 
		</div>
		
</div>

</div>

<!-- </form> -->

<div id="div_result"></div>

<?php include 'template/footer.php'; ?>