<?php

$db_hostname = 'localhost';
$db_username = 'root';
$db_password = '';
$db_database = 'assert_management_system';

// Create connection
$conn = new mysqli($db_hostname, $db_username, $db_password, $db_database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>