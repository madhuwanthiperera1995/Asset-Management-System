<?php

if (isset($_GET['c_file'])) {
    $checklist_id = $_GET['c_file'];
    echo 'fdffa';
    
    echo $sql = "SELECT 
	            * FROM 
		           tbl_checklist 
			    WHERE 
			       checklist_id=$checklist_id";
			   
    $result = mysqli_query($conn, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = 'document/' . $file['name'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; c_file=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('document/' . $file['name']));
        readfile('document/' . $file['name']);

        exit;
    }

}

?>


	<?php 
				if(isset($_POST['save'])){
					if($_FILES['c_file']['name']){

				 
						// here is the current date time timestamp
						$time = date("d-m-Y")."-".time();
				 
						// here we set it to the file name
						$fileName = $_FILES['c_file']['name'];
						$fileName = $time."-".$fileName ;
				         
						// upload that image into the directory name: document
						move_uploaded_file($_FILES['c_file']['tmp_name'], "document/".$fileName);
						$file="document/".$_FILES['c_file']['name'];
				 
					}else{
						echo "Something went wrong";
					}
				} 
            ?>


