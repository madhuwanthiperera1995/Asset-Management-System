<!--<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>	-->	  
 
<?php

 include 'template/header.php';
//echo 'jkjkjk '.$_SESSION['user_level'].'...........mmaadddddddd ';
	if((isset($_SESSION['user_level'])) && (($_SESSION['user_level']=='1') || ($_SESSION['user_level']=='2')))
	{
	include 'db_connect.php';
	
	$assert_id = $_GET['assert_id'];
	
	$edit = "SELECT 
	         *FROM 
			    tbl_assert_master_system 
			  WHERE 
			   `assert_id`='".$_GET['assert_id']."'";	

    $result_ed = $conn->query($edit);
	
	$row = mysqli_fetch_array($result_ed);
	
	if(isset($_POST['update'])) // when click on Update button
{
						    $assert_type = $_POST['assert_type'];
							$assert_ownership = $_POST['assert_ownership'];
							$assert_category = $_POST['assert_category'];
							$assert_name = $_POST['assert_name'];
							$assert_item_code = $_POST['assert_item_code'];
							$assert_brand = $_POST['assert_brand'];
							$assert_model = $_POST['assert_model'];
							$assert_unit_of_measurement = $_POST['assert_unit_of_measurement'];
							$assert_capacity = $_POST['assert_capacity'];
							$assert_location = $_POST['assert_location'];
							$assert_warranty_period = $_POST['assert_warranty_period'];
							$assert_invoiced_amount = $_POST['assert_invoiced_amount'];
							$completion_date = $_POST['completion_date'];
							$assert_amount_insured = $_POST['assert_amount_insured'];
							$assert_responsible_division = $_POST['assert_responsible_division'];
							$assert_supplier = $_POST['assert_supplier'];
							$assert_supplier_address = $_POST['assert_supplier_address'];
							$assert_file_no = $_POST['assert_file_no'];
							$assert_service_agreement = $_POST['assert_service_agreement'];
							$assert_frequency = $_POST['assert_frequency'];
							$assert_milage = $_POST['assert_milage'];
							$expected_time = $_POST['expected_time'];
							$description = $_POST['description'];
							$instructions = $_POST['instructions'];
	
	 $new1 = "UPDATE 
				tbl_assert_master_system 
					SET 
						assert_type = '$assert_type', assert_ownership='$assert_ownership', assert_category='$assert_category', assert_name='$assert_name', assert_item_code='$assert_item_code',
						assert_brand='$assert_brand', assert_model='$assert_model', assert_unit_of_measurement='$assert_unit_of_measurement', assert_capacity='$assert_capacity', assert_location='$assert_location',
						assert_warranty_period='$assert_warranty_period', assert_invoiced_amount='$assert_invoiced_amount', completion_date='$completion_date', assert_amount_insured='$assert_amount_insured', assert_responsible_division='$assert_responsible_division',
						assert_supplier='$assert_supplier', assert_supplier_address='$assert_supplier_address', assert_file_no='$assert_file_no', assert_service_agreement='$assert_service_agreement',
						assert_frequency='$assert_frequency', assert_milage='$assert_milage', expected_time='$expected_time', description='$description', instructions='$instructions' 
					WHERE 
						assert_id = '$assert_id'";
							
  

                        if (mysqli_query($conn, $new1)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $new1 . "
					" . mysqli_error($conn);
						 }
						 

                if($new1)
					{
						mysqli_close($conn); // Close connection
						header("location:assert_master_view.php"); // redirects to all records page
						exit;
					}
					else
					{
						echo mysqli_error();
					}    							 
}
?>		
			

<form action="" method="POST">

<div class="container mt-5">
  <div class="row pt-6" class="row"><center>
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black">Create Item</font></label></b></center>
	</div><br>
 		
       
		
	    <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_type" id="preinput">Assert Type</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_type" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_type" style="width:220px; height:35px" id="assert_type" class="form-control" value="<?php echo $row['assert_type'] ?>">
				  <option value="select"<?php if($row['assert_type']== 'select'){ echo 'selected'; }?>></option>
				  <option value="fixed"<?php if($row['assert_type']== 'fixed'){ echo 'selected'; }?>>Fixed</option>
				  <option value="movable"<?php if($row['assert_type']== 'movable'){ echo 'selected'; }?>>Movable</option>
				  <option value="other"<?php if($row['assert_type']== 'other'){ echo 'selected'; }?>>Other</option>
				  </select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_amount_insured" id="preinput">Amount of Insured</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_amount_insured" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_amount_insured" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_amount_insured']; ?>">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_ownership" id="preinput">Ownership</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_ownership" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_ownership" style="width:220px; height:35px" class="form-control" id="assert_ownership" value="<?php echo $row['assert_ownership']; ?>">
				  <option value="select"<?php if($row['assert_ownership']== 'select'){ echo 'selected'; }?>></option>
				  <option value="10"<?php if($row['assert_ownership']== '10'){ echo 'selected'; }?>>Own</option>
				  <option value="11"<?php if($row['assert_ownership']== '11'){ echo 'selected'; }?>>Hired</option>
				  <option value="12"<?php if($row['assert_ownership']== '12'){ echo 'selected'; }?>>Other</option>
				  </select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_responsible_division" id="preinput">Responsible Division</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_responsible_division" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_responsible_division" style="width:220px; height:35px" class="form-control" id="assert_responsible_division" value="<?php echo $row['assert_responsible_division']; ?>">
				  <option value="select"<?php if($row['assert_responsible_division']== 'select'){ echo 'selected'; }?>></option>
				  <option value="facility"<?php if($row['assert_responsible_division']== 'facility'){ echo 'selected'; }?>>Facility Management</option>
				  <option value="it"<?php if($row['assert_responsible_division']== 'it'){ echo 'selected'; }?>>IT</option>
				  <option value="transport"<?php if($row['assert_responsible_division']== 'transport'){ echo 'selected'; }?>>Transport</option>
				  <option value="admin"<?php if($row['assert_responsible_division']== 'admin'){ echo 'selected'; }?>>Admin</option>
				  </select>
			</div>
			
	   </div>
		
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_category" id="preinput">Assert Category</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_category" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			
				  <select name="assert_category" id="assert_category" style="width:220px; height:35px;" class="form-control" value="<?php echo $row['assert_category']; ?>">
				  <option value="select"<?php if($row['assert_category']== 'select'){ echo 'selected'; }?>></option>
				  <option value="MNT"<?php if($row['assert_category']== 'MNT'){ echo 'selected'; }?>>Maintenance</option>
				  <option value="RMVB"<?php if($row['assert_category']== 'RMVB'){ echo 'selected'; }?>>Removable</option>
				  <option value="ECC"<?php if($row['assert_category']== 'ECC'){ echo 'selected'; }?>>Electronic</option>
				  <option value="ECL"<?php if($row['assert_category']== 'ECL'){ echo 'selected'; }?>>Electrical</option>
				  <option value="MOTOR"<?php if($row['assert_category']== 'MOTOR'){ echo 'selected'; }?>>Motor</option>
				  <option value="FURNITURE"<?php if($row['assert_category']== 'FURNITURE'){ echo 'selected'; }?>>Furniture</option>
				  <option value="COSMR"<?php if($row['assert_category']== 'COSMR'){ echo 'selected'; }?>>Consumer</option>
				  <option value="OTHER"<?php if($row['assert_category']== 'OTHER'){ echo 'selected'; }?>>Other</option>
				  </select>
			
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_supplier" id="preinput">Supplier</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_supplier" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_supplier" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_supplier']; ?>">
			</div>
			

	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_name" id="preinput">Assert Name</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_name" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['assert_name']; ?>">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_supplier_address" id="preinput">Supplier Address</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_supplier_address" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_supplier_address" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_supplier_address']; ?>">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_item_code" id="preinput">Item Code</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_item_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_item_code" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_item_code']; ?>">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_file_no" id="preinput">File No.</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_file_no" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_file_no" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_file_no']; ?>">
			</div>
			
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_brand" id="preinput">Brand</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_brand" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_brand" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_brand']; ?>">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_service_agreement" id="preinput">Service Agreement</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_service_agreement" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_service_agreement" style="width:220px; height:35px" class="form-control" id="assert_service_agreement" value="<?php echo  $row['assert_service_agreement']; ?>">
				  <option value="select"<?php if($row['assert_service_agreement']== 'select'){ echo 'selected'; }?>></option>
				  <option value="supplier"<?php if($row['assert_service_agreement']== 'supplier'){ echo 'selected'; }?>>Supplier</option>
				  <option value="contact"<?php if($row['assert_service_agreement']== 'contact'){ echo 'selected'; }?>>Contact Person</option>
				  <option value="address"<?php if($row['assert_service_agreement']== 'address'){ echo 'selected'; }?>>Address</option>
				  <option value="details"<?php if($row['assert_service_agreement']== 'details'){ echo 'selected'; }?>>Contact Detail</option>
				  </select>
			</div>
			

			
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_model" id="preinput">Model</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_model" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_model" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_model']; ?>">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_frequency" id="preinput">Frequency of Maintainance</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_frequency" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_frequency" style="width:220px; height:35px" class="form-control" id="assert_frequency" value="<?php echo $row['assert_frequency']; ?>">
				  <option value="select"<?php if($row['assert_frequency']== 'select'){ echo 'selected'; }?>></option>
				  <option value="weekly"<?php if($row['assert_frequency']== 'weekly'){ echo 'selected'; }?>>Weekly</option>
				  <option value="monthly"<?php if($row['assert_frequency']== 'monthly'){ echo 'selected'; }?>>Monthly</option>
				  <option value="quartly"<?php if($row['assert_frequency']== 'quartly'){ echo 'selected'; }?>>Quartly</option>
				  <option value="annually"<?php if($row['assert_frequency']== 'annually'){ echo 'selected'; }?>>Annually</option>
				  </select>
			</div>	
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_unit_of_measurement" id="preinput">Unit of Measurement</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_unit_of_measurement" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="assert_unit_of_measurement" style="width:220px; height:35px" class="form-control" id="assert_unit_of_measurement" value="<?php echo $row['assert_unit_of_measurement']; ?>">
				  <option value="select"<?php if($row['assert_unit_of_measurement']== 'select'){ echo 'selected'; }?>><option>
				  <option value="nos"<?php if($row['assert_unit_of_measurement']== 'nos'){ echo 'selected'; }?>>Nos</option>
				  <option value="packs"<?php if($row['assert_unit_of_measurement']== 'packs'){ echo 'selected'; }?>>Packs</option>
				  <option value="kg"<?php if($row['assert_unit_of_measurement']== 'kg'){ echo 'selected'; }?>>Kg</option>
				  <option value="g"<?php if($row['assert_unit_of_measurement']== 'g'){ echo 'selected'; }?>>g</option>
				  <option value="dozen"<?php if($row['assert_unit_of_measurement']== 'dozen'){ echo 'selected'; }?>>Dozen</option>
				  </select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="assert_milage" id="preinput">Milage of Maintenance</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_milage" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_milage" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_milage']; ?>">
			</div>
			
			

			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_capacity" id="preinput">Capacity</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_capacity" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_capacity" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_capacity']; ?>">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="expected_time" id="preinput">Expected time of Consuming</label>
			</div>
			<div class="col-sm-1">
				<label for="expected_time" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="date" class="form-control" name="expected_time" style="width:220px; height:35px" id="inputid" value="<?php echo $row['expected_time']; ?>">
			</div>
			

			
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_location" id="preinput">Location</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_location" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			
				  <select name="assert_location" id="assert_location" style="width:220px; height:35px;" class="form-control" value="<?php echo $row['assert_location']; ?>">
				  <option value="select"<?php if($row['assert_location']== 'select'){ echo 'selected'; }?>></option>
				  <option value="3"<?php if($row['assert_location']== '3'){ echo 'selected'; }?>>CGR</option>
				  <option value="1"<?php if($row['assert_location']== '1'){ echo 'selected'; }?>>First floor A side</option>
				  <option value="2"<?php if($row['assert_location']== '2'){ echo 'selected'; }?>>First floor B side</option>
				  <option value="4"<?php if($row['assert_location']== '4'){ echo 'selected'; }?>>Ground floor A side</option>
				  <option value="5"<?php if($row['assert_location']== '5'){ echo 'selected'; }?>>Ground floor B side</option>
				  </select>
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="description" id="preinput">Description</label>
			</div>
			<div class="col-sm-1">
				<label for="description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="description" style="width:220px; height:35px" id="inputid" value="<?php echo $row['description']; ?>">
			</div>
			
	  </div>
	  
	  <div class="row pt-2">
	  		<div class="col-sm-2" id="div1">
			<label for="assert_warranty_period" id="preinput">Warranty Period</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_warranty_period" id="preinput">:</label>
			</div>
			<div class="col-sm-2" id="div1">
				<input type="text" class="form-control" name="assert_warranty_period" style="width:220px; height:35px" id="assert_warranty_period" id="inputid" value="<?php echo $row['assert_warranty_period']; ?>">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="instructions" id="preinput">Instructions of Maintenance</label>
			</div>
			<div class="col-sm-1">
				<label for="instructions" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="instructions" style="width:220px; height:35px" id="inputid" value="<?php echo $row['instructions']; ?>">
			</div>
			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2">
				<label for="assert_invoiced_amount" id="preinput">Invoiced Amount</label>
			</div>
			<div class="col-sm-1">
				<label for="assert_invoiced_amount" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="assert_invoiced_amount" style="width:220px; height:35px" id="inputid" value="<?php echo $row['assert_invoiced_amount']; ?>">
			</div>
			

			
	  </div>
	  
	  <div class="row pt-2">
			<div class="col-sm-2" id="div1">
				<label for="completion_date" id="preinput">Date of Completion</label>
			</div>
			<div class="col-sm-1">
				<label for="completion_date" id="preinput">:</label>
			</div>
			<div class="col-sm-2" id="div1">
				<input type="date" class="form-control" name="completion_date" id="inputid" style="width:220px; height:35px" id="completion_date" value="<?php echo $row['completion_date']; ?>">
			</div>
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2"></div>
			
			<div class="col-sm-1">				
				<button type="update" name="update">Update</button>
			</div>
			
			<div class="col-sm-2"></div>
				
	  </div>
	  
	 
  
</div>

</form>

<?php
	}
	else{
		echo "You do not have access to this page... Please contact admin or manager";
		?>
		<button type="home" name="home" style="background-color:gray"><a href="home_page.php">Home</a></button>
		<button type="back" name="back" style="background-color:gray"><a href="user_view.php">Back</a></button>
		<?php
	}
	
  ?>
</body>
</html>