<!--<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>	-->	  
 
<?php

		include 'template/header.php';
		//echo 'jkjkjk '.$_SESSION['user_level'].'...........mmaadddddddd ';
			if((isset($_SESSION['user_level'])) && (($_SESSION['user_level']=='1') || ($_SESSION['user_level']=='2')))
			{		  
		 
	include 'db_connect.php';
	
	$e_year_id = $_GET['e_year_id'];
	
	$edit = "SELECT 
	         *FROM 
			    tbl_extra_assets 
			  WHERE 
			   `e_year_id`='".$_GET['e_year_id']."'";	

    $result_ed = $conn->query($edit);
	
	$row = mysqli_fetch_array($result_ed);
	
	if(isset($_POST['update'])) // when click on Update button
{
						    $e_assert_type = $_POST['e_assert_type'];
							$e_2019 = $_POST['e_2019'];
							$e_2020 = $_POST['e_2020'];
							$e_2021 = $_POST['e_2021'];
							$e_2022 = $_POST['e_2022'];
							$e_2023 = $_POST['e_2023'];
							
	 $new1 = "UPDATE 
				tbl_extra_assets 
					SET 
						e_assert_type = '$e_assert_type', e_2019='$e_2019', e_2020='$e_2020', e_2021='$e_2021', e_2022='$e_2022', e_2023='$e_2023'
					WHERE 
						e_year_id = '$e_year_id'";
							
  

                        if (mysqli_query($conn, $new1)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $new1 . "
					" . mysqli_error($conn);
						 }
						 

                if($new1)
					{
						mysqli_close($conn); // Close connection
						header("location:other_assets_view.php"); // redirects to all records page
						exit;
					}
					else
					{
						echo mysqli_error();
					}    							 
}
?>		
			

<form action="" method="POST">

<div class="container mt-5">
  
  <div class="row pt-6" class="row">
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black"></font></label></b>
	</div><br>
 		
		<div class="row pt-2">
		    <div class="col-sm-1"></div>
			<div class="col-sm-2">
				<label for="" id="preinput"><font size="6px" color="black"><b>Asset</b></font></label>
			</div>
		</div>
       
		
	    <div class="row pt-2">
		    <div class="col-sm-1"></div>
			<div class="col-sm-2">
				<label for="e_assert_type" id="preinput">Assert Type</label>
			</div>
			<div class="col-sm-1">
				<label for="e_assert_type" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="e_assert_type" style="width:220px; height:35px" id="e_assert_type" class="form-control" value="<?php echo $row['e_assert_type'] ?>">
				  <option value="select"<?php if($row['e_assert_type']== 'select'){ echo 'selected'; }?>></option>
				  <option value="fixed"<?php if($row['e_assert_type']== 'LVAL'){ echo 'selected'; }?>>Land Value</option>
				  <option value="movable"<?php if($row['e_assert_type']== 'BVAL'){ echo 'selected'; }?>>Building Value</option>
				  <option value="other"<?php if($row['e_assert_type']== 'PCOUNT'){ echo 'selected'; }?>>Passenger Count</option>
				  <option value="fixed"<?php if($row['e_assert_type']== 'CGRREV'){ echo 'selected'; }?>>CGR Revenue</option>
				  <option value="movable"<?php if($row['e_assert_type']== 'PNREV'){ echo 'selected'; }?>>P&N Revenue</option>
				  <option value="other"<?php if($row['e_assert_type']== 'RESTAURANT'){ echo 'selected'; }?>>Restaurant</option>
				  <option value="fixed"<?php if($row['e_assert_type']== 'JUICEBR'){ echo 'selected'; }?>>Juice Bar</option>
				  <option value="movable"<?php if($row['e_assert_type']== 'BANK'){ echo 'selected'; }?>>Bank</option>
				  <option value="other"<?php if($row['e_assert_type']== 'JANITORIAL'){ echo 'selected'; }?>>Janitorial</option>
				  
				  </select>
			</div>
		</div>
		
		<div class="row pt-2">
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="e_2019" id="preinput">2019</label>
			</div>
			<div class="col-sm-1">
				<label for="e_2019" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="e_2019" style="width:220px; height:35px" id="inputid" value="<?php echo $row['e_2019']; ?>">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="e_2020" id="preinput">2020</label>
			</div>
			<div class="col-sm-1">
				<label for="e_2020" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="e_2020" style="width:220px; height:35px" id="inputid" value="<?php echo $row['e_2020']; ?>">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="e_2021" id="preinput">2021</label>
			</div>
			<div class="col-sm-1">
				<label for="e_2021" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="e_2021" style="width:220px; height:35px" id="inputid" value="<?php echo $row['e_2021']; ?>">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="e_2022" id="preinput">2022</label>
			</div>
			<div class="col-sm-1">
				<label for="e_2022" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="e_2022" style="width:220px; height:35px" id="inputid" value="<?php echo $row['e_2022']; ?>">
			</div>
	  </div>
	  
	  <div class="row pt-2">
			
			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
				<label for="e_2023" id="preinput">2023</label>
			</div>
			<div class="col-sm-1">
				<label for="e_2023" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" name="e_2023" style="width:220px; height:35px" id="inputid" value="<?php echo $row['e_2023']; ?>">
			</div>
	  </div>
		
      <div class="row pt-2">
	        
	        <div class="col-sm-1"></div>
			<div class="col-sm-2"></div>
			
			<div class="col-sm-1">				
				<button type="update" name="update"><center>Update</center></button>
			</div>
			
			<div class="col-sm-2"></div>
				
	  </div>
	  
	 
  
</div>

</form>

 <?php
	}
	else{
		echo "You do not have access to this page... Please contact admin or manager";
		?>
		<button type="home" name="home" style="background-color:gray"><a href="home_page.php">Home</a></button>
		<button type="back" name="back" style="background-color:gray"><a href="user_view.php">Back</a></button>
		<?php
	}
	
  ?>
  
</body>
</html>