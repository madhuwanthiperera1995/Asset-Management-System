<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  
<style> 
		
		#menu-bar
		{
			background: rgb(0,100,0);
			text-align: center;
		}
		
		#menu-bar ul
		{
			display: inline-flex;
			list-style: none;
			color: #fff;
		}
		
		#menu-bar ul li
		{
			width: 170px;
			margin: 5px;
			padding: 5px;
		}
		
		#menu-bar ul li a
		{
			text-decoration: none;
			color: #fff;
			
		}
		
		#active, #menu-bar ul li:hover
		{
			background: #2bab0d;
			border-radius: 3px;
			
		}
		
		#menu-bar .fa
		{
			margin-right: 8px;
		}
		
		#sub-menu-1
		{
			display: none;
		}
		
		#menu-bar ul li:hover #sub-menu-1
		{
			display: block;
			position: absolute;
			background: rgb(0,100,0);
			margin-top: 15px;
			margin-left: -10px;
			
		}	

        #menu-bar ul li:hover #sub-menu-1 ul
		{
			display: block;
			margin: 10px;
		}
		
        #menu-bar ul li:hover #sub-menu-1 ul li
		{
			width:170px;
			padding: 8px;
			border-bottom: 1px dotted #fff;
			background: transparent;
			border-radius: 0;
			text-align: left;
		}

        #menu-bar ul li:hover #sub-menu-1 ul li:last-child
		{
			border-bottom: none;
		}

        #menu-bar ul li:hover #sub-menu-1 ul li a:hover	
		{
			color: #b2ff00;
		}

        .fa-angle-right
		{
			float: right;
		}

		#sub-menu-2
		{
			display: none;
		}
		
		#hover-me:hover #sub-menu-2
		{
			position: absolute;
			display: block;
			margine-top: -40px;
			margine-left: 50px;
			background: rgb(0,100,0);
		}
</style>
  
  
 <script>
 
function confirmact(txt)
{
alert(txt)
}
 	
	function confirmact() {
        let confirmact = confirm("Are you want to logout?");
		
        if (confirmact) {
          alert("Successfully Logout");
		  location.replace("user_loging.php")
		} 
         else {
          alert("Logout canceled");
		  location.replace("home_page.php")
        }
      }
	
 </script>
  

</head>


<body>

				<?php
							
							if(isset($_POST['logout']))
							{	 
							

							include 'logout.php';
							
							
							/*logout*/
							$qry =  $conn -> real_escape_string($logout);
																		
							$sql = "INSERT INTO tbl_activity_log (`user_id`,`module`,`activity`,`description`,`query`,`date`,`time`,`ip_address`) 
										values ('".$_session['user_id']."','user','Logout','Successfull Logout','".$qry."',
										NOW(),NOW(), '".$_SERVER['REMOTE_ADDR']."')" ;
																					
							$sql_query = $conn->query($sql);
							
							if($sql){
								session_start();}
								session_destroy();{
								  
								unset($_SESSION["user_id"]);
								header("Location: user_loging.php");
								
								}
							}
							
						?>
						
						<?php
						 
							class log
							{  
								CONST ENVIRONMENT = 'development';

								private $act_id;
								private $user_id;
								protected $module;
								protected $activity;
								protected $description;
								protected $query;
								protected $ip_address;
								protected $date;
								protected $time;
								

								public function __construct(string $module, string $activity, string $description, string $query)
								{
									if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
										$ip_address = $_SERVER['HTTP_CLIENT_IP'];
									} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
										$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
									} else {
										$ip_address = $_SERVER['REMOTE_ADDR'];
									}
									
									if(!empty($_SESSION['user_id'])){
										$user_id = $_SESSION['user_id'];
									}else {
										  $id = 0;
										  }
									$this->user_id = $user_id;
									$this->module = $module;
									$this->activity = $activity;
									$this->description = $description;
									$this->query = $query;
									$this->ip_address = $ip_address;
								}

								public function createAction()
								{
									global $conn;

									if(!$conn) {
									   echo mysqli_error($conn); die;
									}

									if(!$sql_query){
										echo mysqli_error($conn); die;
									}

									if(ENVIRONMENT == 'development'){
										$_SESSION['msg'] = 'User Logout ' . $this->act_id;
									}
									
								} }

						
						?>
											


<div class="container-fluid pt-3 bg-primary text-white text ali-left">
  <center><h1><font color="black" size="50px"><b>Makumbura Multi Modal Center - Kottawa</b></font></h1></center>
</div>


  
	<div id="menu-bar">
      <ul >
			   <li id="active">
				  <a href="home_page.php">Home</a>
				</li>
				 
				<li >
					  <a  href="#">User Registration</a>
					  <div id="sub-menu-1">
						  <ul >
							<li><a  href="#">User</a></li>
							<li><a href="add_user.php">Add User</a></li>
							<li><a  href="user_view.php">View</a></li>
						  </ul>
					  </div>
				</li>
				
				 <li class="nav-item dropdown">
					  <a  href="#">Checklist</a>
					  <div id="sub-menu-1">
						  <ul>
							<li><a  href="checklist.php">Add</a></li>
							<li><a href="checklist_view.php">View</a></li>
						  </ul>
					  </div>
				</li>
						
				<li class="nav-item dropdown">
					  <a href="#" >Insident</a>
					  <div id="sub-menu-1">
						  <ul>
							<li><a href="incident.php">Add</a></li>
							<li><a href="#">View</a></li>
						  </ul>
					  </div>
				</li>
					
				<li class="nav-item dropdown">
					  <a href="#">Breakdown</a>
					  <div id="sub-menu-1">
						  <ul>
							<li><a href="breakdown.php">Add</a></li>
							<li><a href="#">View</a></li>
						  </ul>
					  </div>
				</li>
				
				
						
				<li class="nav-item dropdown">
					  <a  href="#">Sys Settings</a>
					  <div id="sub-menu-1">
							  <ul>
									   <li id="hover-me"><a href="#">MMC Information ></a><i class="fa fa-angle-right"></i>
											<div id="sub-menu-2">
											<ul>
												<li><a href="sys_setting.php">Add</a></li>
												<li><a href="sys_setting_view.php">View</a></li>
											</ul>
											</div>
									   </li>
										
										<li id="hover-me"><a  href="#">Zone Information ></a><i class="fa fa-angle-right"></i>
											<div id="sub-menu-2">
											<ul>
												<li><a href="sys_setting.php">Add</a></li>
												<li><a href="sys_setting_view.php">View</a></li>
											</ul>
											</div>
										</li>
										
										<li id="hover-me"><a href="#">Assert Category    ></a><i class="fa fa-angle-right"></i>
										    <div id="sub-menu-2">
											<ul>
												<li><a href="sys_setting.php">Add</a></li>
												<li><a href="sys_setting_view.php">View</a></li>
											</ul>
											</div>
										</li>
										
										<li id="hover-me"><a href="#">Unit of Measure    ></a><i class="fa fa-angle-right"></i>
										    <div id="sub-menu-2">
											<ul>
												<li><a href="sys_setting.php">Add</a></li>
												<li><a href="sys_setting_view.php">View</a></li>
											</ul>
											</div>
										</li>
								
							  </ul>
						</div>
				</li>
				
				
				
				<li class="nav-item">
					 <button onclick="confirmact()" value="Submit" style="background-color:gray" type="logout" name="logout"><a class="nav-link"><font color="black"><b>Logout</b></font></a></button>
				</li> 
					 
			</ul>				

		</div>
	


</body>

</html>