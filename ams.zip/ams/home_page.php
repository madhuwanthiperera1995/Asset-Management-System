<?php include 'template/header.php'; ?>


			
<center>
<div class="container mt-2">
   <img src="logo.png" alt="Makumbura Multimodal" class="mx-auto d-block" style="width:40%">
</div>
</center>

<?php include 'template/footer.php'; ?>