<?php include 'template/header.php'; ?>
  <!--<script>
  $(document).ready(function(){
					$("#inputid").keyup(function(){
						$.ajax({
						type: "POST",
						url: "assert_ajax.php",
						data:'keyword='+$(this).val(),
						beforeSend: function(){
							$("#inputid").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
						},
						success: function(data){
							$("#suggesstion_box").show();
							$("#suggesstion_box").html(data);
							$("#inputid").css("background","#FFF");
						}
						});
					});
				});	

  
  </script>
  <style>
  .solid {
  border-style: solid;
  }
  </style>-->
  
   <?php
	include 'db_connect.php';
	?>
  
  <?php
					if(isset($_POST['save']))
					{	 
						    
							$i_item_no = $_POST['i_item_no'];
							$i_date = $_POST['i_date'];
							$i_time = $_POST['i_time'];
							$i_type_incident = $_POST['i_type_incident'];
							$i_social_impact = $_POST['i_social_impact'];
							$i_reason = $_POST['i_reason'];
							$i_action = $_POST['i_action'];
							$i_special_remarks = $_POST['i_special_remarks'];
							$i_damages = $_POST['i_damages'];
							$time = date("d-m-Y")."-".time();
							$i_image = $_FILES['i_image']['name'];
							$i_image = $time."-".$i_image;
							
							
							$sql = "INSERT INTO tbl_incident(
							i_item_no,i_date,i_time,i_type_incident,i_social_impact,i_reason,i_action,
							i_special_remarks,i_damages,i_image,image_time,i_active_status)
							
							VALUES ( 
							'".$i_item_no."','".$i_date."','".$i_time."','".$i_type_incident."','".$i_social_impact."','".$i_reason."','".$i_action."',
							'".$i_special_remarks."','".$i_damages."','".$i_image."',NOW(),1)";
							
							//$_SESSION['breakdown_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
			?>
			
			<?php 
				if(isset($_POST['save'])){
					if($_FILES['i_image']['name']){

				 
						// here is the current date time timestamp
						$time = date("d-m-Y")."-".time();
				 
						// here we set it to the file name
						$fileName = $_FILES['i_image']['name'];
						$fileName = $time."-".$fileName ;
				         
						// upload that image into the directory name: images
						move_uploaded_file($_FILES['i_image']['tmp_name'], "images/".$fileName);
						$file="images/".$_FILES['i_image']['name'];
				 
					}else{
						echo "Something went wrong";
					}
				} 
            ?>


<form action="" method="POST" enctype="multipart/form-data">

<div class="container mt-5">

 
  <div class="row pt-2">
   <div class="col-sm-3"><font size="6px"><b>Incident Records</b></font></div>
  </div><br>
  
  <div class="row pt-2">
	<div class="col-sm-2">
		<label for="i_item_no" id="preinput">Item No</label>
	</div>
	<div class="col-sm-1">
		<label for="i_item_no" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
		<input type="text" class="form-control" style="width:310px; height:40px;" list="suggesstion_box" name="i_item_no" id="inputid">
		<div id="suggesstion_box"></div>
	</div>
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-7">
	<p class="solid"></p>
	</div>
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_date" id="preinput">Date</label>
	</div>
	<div class="col-sm-1">
		<label for="i_date" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="date" class="form-control" style="width:310px; height:40px;" name="i_date" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_time" id="preinput">Time</label>
	</div>
	<div class="col-sm-1">
		<label for="i_time" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="time" class="form-control" style="width:310px; height:40px;" name="i_time" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_type_incident" id="preinput">Type of Incident</label>
	</div>
	<div class="col-sm-1">
		<label for="i_type_incident" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
		  <select name="i_type_incident" id="i_type_incident" style="width:310px; height:40px;"  class="form-control">
		  <option value=""></option>
		  <option value="accident">Accident</option>
		  <option value="natural_disaster">Natural Disaster</option>
		  <option value="fire">Fire</option>
		  </select>
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_social_impact" id="preinput">Social Impact</label>
	</div>
	<div class="col-sm-1">
		<label for="i_social_impact" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="i_social_impact" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_reason" id="preinput">Reason</label>
	</div>
	<div class="col-sm-1">
		<label for="i_reason" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="i_reason" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_action" id="preinput">Action Taken</label>
	</div>
	<div class="col-sm-1">
		<label for="i_action" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="i_action" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_special_remarks" id="preinput">Special Remarks</label>
	</div>
	<div class="col-sm-1">
		<label for="i_special_remarks" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="i_special_remarks" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_damages" id="preinput">Assesment of Damages</label>
	</div>
	<div class="col-sm-1">
		<label for="i_damages" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="text" class="form-control" style="width:310px; height:40px;" name="i_damages" id="inputid">
	</div> 
  </div>
  
  <div class="row pt-2">
	<div class="col-sm-2">
	<label for="i_image" id="preinput">Image/s</label>
	</div>
	<div class="col-sm-1">
		<label for="i_image" id="preinput">:</label>
	</div>
	<div class="col-sm-3">
	<input type="file" id="i_image" name="i_image"  id="inputid" accept=".jpg,.png" value="i_image"/><br><br>
	<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;">Save</button>
	</div> 
  </div>
  

   
 </div>
 </form>
<?php include 'template/footer.php'; ?>