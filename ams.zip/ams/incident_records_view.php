
	<?php 
			session_start();
			include 'db_connect.php';
			if(isset ($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';
					$i_date = $_GET['i_date'];
					$i_time = $_GET['i_time'];
					$i_type_incident = $_GET['i_type_incident']; 
					$i_action = $_GET['i_action'];
					$i_reason = $_GET['i_reason'];
				
					
					$filter = "1=1 ";
					
					if(isset($_GET['incident_id']) && ($_GET['incident_id']!=''))
					{
						$filter .= " AND `incident_id` LIKE '%".$_GET['incident_id']."%'";
					}
					
					if(isset($_GET['i_date']) && ($_GET['i_date']!=''))
					{
						$filter .= " AND `i_date` LIKE '%".$_GET['i_date']."%'";
					}
					
					if(isset($_GET['i_time']) && ($_GET['i_time']!=''))
					{
						$filter .= " AND `i_time` LIKE '%".$_GET['i_time']."%'";
					}
					
					
					if(isset($_GET['i_type_incident']) && ($_GET['i_type_incident']!='0'))
					{
						$filter .= " AND `i_type_incident` = '".$_GET['i_type_incident']."'";
					}	
					
					if(isset($_GET['i_action']) && ($_GET['i_action']!=''))
					{
						$filter .= " AND `i_action` LIKE '%".$_GET['i_action']."%'";
					}
					
					if(isset($_GET['i_reason']) && ($_GET['i_reason']!=''))
					{
						$filter .= " AND `i_reason` LIKE '%".$_GET['i_reason']."%'";
					}     
					
					
					if(isset($_GET['i_damages']) && ($_GET['i_damages']!=''))
					{
						$filter .= " AND `i_damages` LIKE '%".$_GET['i_damages']."%'";
					}
					
					if(isset($_GET['i_image']) && ($_GET['i_image']!=''))
					{
						$filter .= " AND `i_image` LIKE '%".$_GET['i_image']."%'";
					}
						
					
					echo $view = "SELECT 
									`incident_id`,`i_date`,`i_time`,`i_type_incident`,`i_action`,`i_reason`,`i_damages`,`i_image` 
								FROM 
									tbl_incident 
								WHERE 
									$filter";
				    //echo '2222';
				    
					$result = $conn->query($view);

							
			}
			else{
				echo "Invalid Calling Method!";
				
			}
        //echo 'mklslkfjsafj';
?>
		
		 <?php 
				if(isset($_POST['download'])){
					if($_FILES['checklist_file']['name']){

				 
						// here is the current date time timestamp
						$time = date("d-m-Y")."-".time();
				 
						// here we set it to the file name
						$fileName = $_FILES['i_image']['name'];
						$fileName = $time."-".$fileName ;
				         
						// upload that image into the directory name: images
						move_uploaded_file($_FILES['i_image']['tmp_name'], "images/".$fileName);
						$file="images/".$_FILES['i_image']['name'];
				 
					}else{
						echo "Something went wrong";
					}
				} 
            ?>
			
					

			
<div class="container">
   <br/>
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">Asset View</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Date</th>
								<th>Time</th>
								<th>Type of incident</th>
								<th>Action</th>
								<th>Reason</th>
								<th>Damages</th>
								<th>Image</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
								//echo 'kkkkkk';
						?>
						
							<tr>
								<td><?php echo $row['incident_id']; ?></td>
							    <td><?php echo $row['i_date']; ?></td>
								<td><?php echo $row['i_time']; ?></td>
								<td><?php echo $row['i_type_incident']; ?></td>
								<td><?php echo $row['i_action']; ?></td>
								<td><?php echo $row['i_reason']; ?></td>
								<td><?php echo $row['i_damages']; ?></td>
								<td><?php echo $row['i_image']; ?></td>
								
								<td><button type="button" name="download" id="download" class="btn btn-warning bt-xs download">
								<a href="images/<?php
								                     echo $row['i_image']; 
												   ?> " target="_BLANK"> View File </a></button></td>
							</tr>
							
						<?php
							}
						?>
						</tbody>
							
						</table>
					</div>
					</div>
				</div>
	</hr>

</div>
