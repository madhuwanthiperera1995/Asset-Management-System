  <?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var i_date = $('#i_date').val(); 
						var i_time = $('#i_time').val();
						var i_type_incident = $('#i_type_incident').val();
						var i_action = $('#i_action').val(); 
						var i_reason = $('#i_reason').val();
						var click='TRUE';
			
			
			
			url='incident_records_view.php?click=true&i_type_incident='+i_type_incident+'';
			//alert(url);
				
			$.ajax({
				url:'incident_records_view.php?click=true&i_type_incident='+i_type_incident+'',
				type: 'GET',
				data: '&i_date='+i_date+'&i_time='+i_time+'&i_type_incident='+i_type_incident+'&i_action='+i_action+'&i_reason='+i_reason+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
		



                       

</script>					  




<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">
							<div class="container mt-5">
							  <div class="row pt-6"><center>
								</div><br>
								
							<div class="row pt-2">
										<label for="" id="preinput"><font size="6px"><center><b>Incident View</b></center></font></label>
							
							</div><br>

							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="i_date" id="preinput">Date</label>
										</div>
										<div class="col-sm-1">
											<label for="i_date" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											
											 <input type="date" class="form-control"  name="i_date" id="i_date" >
										</div>
							</div>
										
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="i_time" id="preinput">Time</label>
										</div>
										<div class="col-sm-1">
											<label for="i_time" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="time" class="form-control"  name="i_time" id="i_time" >
										</div>
							</div>
							
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="i_type_incident" id="preinput">Type of incident</label>
										</div>
										<div class="col-sm-1">
											<label for="i_type_incident" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											  <select name="i_type_incident" id="i_type_incident" style="width:190px; height:40px;"  class="form-control">
											  <option value="0"></option>
											  <option value="accident">Accident</option>
											  <option value="natural_disaster">Natural Disaster</option>
											  <option value="fire">Fire</option>
											  </select>
										</div>
							</div>
							
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="i_action" id="preinput">Action</label>
										</div>
										<div class="col-sm-1">
											<label for="i_action" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="i_action" id="i_action" >
										</div>
							</div>
							
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="i_reason" id="preinput">Reason</label>
										</div>
										<div class="col-sm-1">
											<label for="i_reason" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="i_reason" id="i_reason" >
										</div>
							</div>
							
							<br>

							
							<div class="row pt-2">
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
										
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
												
												<div class="col-sm-2"></div>
												
												<div class="col-sm-1" class="div1">
													<button name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
												</div>
												<div class="col-sm-2"></div>
										</div>
							</div>

</div>

</div>
<!-- </form> -->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>

