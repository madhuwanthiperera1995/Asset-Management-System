<?php

    session_destroy();
      
    header("Location: user_loging.php")
?>

 <script>
		$(document).ready(function(){
		  $("button").click(function(){
			  var formData ={
				assert_type: $("#assert_type").val(),
				item_code: $("#item_code").val(),
				assert_category: $("#assert_category").val(),
				brand: $("#brand").val(),
				assert_name: $("#assert_name").val(),
				model: $("#model").val(),
				location: $("#location").val(),
				completion_date: $("#completion_date").val(),
				assert_warranty_period: $("#assert_warranty_period").val(),
				};
				
			$.ajax({url: "a_master_view.php",data: formData, success: function(result){
			  $("#div1").html(result);
			}});
		  });
		});
  </script>