$(document).on('click', '.update', function(){
				  $('#assert_id').val($(this).attr("assert_id"));
				  $('#assert_type').val('assert_type'));
				  $('#assert_category').val('assert_category');
				  $('#assert_name').val('update');
				  $('#assert_item_code').val('update');
				  $('#assert_brand').val('update');
				  $('#assert_model').val('update');
				  $('#assert_location').val('update');
				 });
				 
			 $(document).on('click', '.delete', function(){
			  var assert_type = $(this).attr("assert_id");
			  var action = "delete";
			  if(confirm("Are you sure you want to remove data from database?"))
			  {
			   $.ajax({
				url:"a_master_view.php",
				method:"GET",
				data:{assert_id:assert_id, action:action},
				success:function(data)
				{
				 alert(data);
				 fetch_data();
				}
			   })
			  }
			  else
			  {
			   return false;
			  }
		    });