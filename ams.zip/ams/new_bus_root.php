<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Bus Root
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<style>
#div-1 {
    	background-color: #ffc107;
    }
	
#div-2 {
		background-color: #000;
    }
	
#welcome{
    padding-top: 2px;
    padding-bottom: 30px;
    
 }

#textWelcome{
   vertical-align: middle;
   font-family: 'Georgia';
   color: rgb(255, 255, 255); /*white text*/
   font-weight: bold;
}
	
</style>

<body>

<div class="row pt-50" id="div-2">
  <label for="new" id="preinput" class="form_style"><font size="20px" color="red"><center><b>බහුවිධ මධ්‍යස්ථානය</b></center></font></label><br>
  <label for="new2" id="preinput" class="form_style"><font size="10px" color="red"><center><b>New Bus Services</b></center></font></label>
</div>

			<div class="row pt-3" id="div-1">
								<div class="col-sm-3"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="black"><center><b>ඇඹිලිපිටිය</b></center></font></label>
								</div>
								
								<div class="col-sm-1"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="black"><center><b>මොණරාගල</b></center></font></label>
								</div>
								
								
			</div>
			
			<div class="row pt-3" id="div-2">
								<div class="col-sm-3"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="white"><center><b>මහනුවර</b></center></font></label>
								</div>
								
								<div class="col-sm-1"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="white"><center><b>කුරුණෑගල</b></center></font></label>
								</div>
								
								
			</div>
			
			<div class="row pt-3" id="div-1">
								<div class="col-sm-3"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="black"><center><b>අනුරාධපුර</b></center></font></label>
								</div>
								
								<div class="col-sm-1"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="black"><center><b>මුලතිව්</b></center></font></label>
								</div>
								
								
			</div>
			
			
			<div class="row pt-3" id="div-2">
								<div class="col-sm-3"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="white"><center><b>බදුල්ල</b></center></font></label>
								</div>
								
								<div class="col-sm-1"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="white"><center><b>බිබිල (කරාඩුගල)</b></center></font></label>
								</div>
								
								
			</div>
			
			<div class="row pt-3" id="div-1">
								<div class="col-sm-3"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="black"><center><b>මඩොල්සිම</b></center></font></label>
								</div>
								
								<div class="col-sm-1"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="black"><center><b>අම්පාර</b></center></font></label>
								</div>
								
								
			</div>
			
			<div class="row pt-3" id="div-2">
								<div class="col-sm-3"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="white"><center><b>අක්කරපත්තු</b></center></font></label>
								</div>
								
								<div class="col-sm-1"></div>
								
								<div class="col-sm-3" class="container fill-height" id="welcome" id="textWelcome">
								    <label for="embilipitiya" id="preinput" class="form_style" ><font size="6px" color="white"><center><b>ගම්පොල</b></center></font></label>
								</div>
								
								
			</div>
			
			

</body>

</html>