
	<?php 
			session_start();
			include 'db_connect.php';
			if(isset ($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';
					$e_assert_type = $_GET['e_assert_type'];
					$e_2019 = $_GET['e_2019'];
					$e_2020 = $_GET['e_2020']; 
					$e_2021 = $_GET['e_2021'];
					$e_2022 = $_GET['e_2022'];
					$e_2023 = $_GET['e_2023'];
				
					
					$filter = "1=1 ";
					
					if(isset($_GET['e_year_id']) && ($_GET['e_year_id']!=''))
					{
						$filter .= " AND `e_year_id` LIKE '%".$_GET['e_year_id']."%'";
					}
					
					if(isset($_GET['e_assert_type']) && ($_GET['e_assert_type']!='0'))
					{
						$filter .= " AND `e_assert_type` = '".$_GET['e_assert_type']."'";
					}
					
					if(isset($_GET['e_2019']) && ($_GET['e_2019']!=''))
					{
						$filter .= " AND `e_2019` LIKE '%".$_GET['e_2019']."%'";
					}
					
					
					if(isset($_GET['e_2020']) && ($_GET['e_2020']!='0'))
					{
						$filter .= " AND `e_2020` LIKE '%".$_GET['e_2020']."%'";
					}	
					
					if(isset($_GET['e_2021']) && ($_GET['e_2021']!=''))
					{
						$filter .= " AND `e_2021` LIKE '%".$_GET['e_2021']."%'";
					}
					
					if(isset($_GET['e_2022']) && ($_GET['e_2022']!=''))
					{
						$filter .= " AND `e_2022` LIKE '%".$_GET['e_2022']."%'";
					}     
					
					
					if(isset($_GET['e_2023']) && ($_GET['e_2023']!=''))
					{
						$filter .= " AND `e_2023` LIKE '%".$_GET['e_2023']."%'";
					}
						
					
					 $view = "SELECT 
									`e_year_id`,`e_assert_type`,`e_2019`,`e_2020`,`e_2021`,`e_2022`,`e_2023` 
								FROM 
									tbl_extra_assets 
								WHERE 
									$filter";
				    //echo '2222';
				    
					$result = $conn->query($view);

							
			}
			else{
				echo "Invalid Calling Method!";
				
			}
        //echo 'mklslkfjsafj';
			
					
?>
			
<div class="container">
   <br/>
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">Asset View</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
								<th>ID</th>
								<th>Asset Type</th>
								<th>2019</th>
								<th>2020</th>
								<th>2021</th>
								<th>2022</th>
								<th>2023</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
						?>
						
							<tr>
								<td><?php echo $row['e_year_id']; ?></td>
							    <td><?php echo $row['e_assert_type']; ?></td>
								<td><?php echo $row['e_2019']; ?></td>
								<td><?php echo $row['e_2020']; ?></td>
								<td><?php echo $row['e_2021']; ?></td>
								<td><?php echo $row['e_2022']; ?></td>
								<td><?php echo $row['e_2023']; ?></td>
								
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['e_year_id'].'" id="edit"><a href="edit_other_asset.php?e_year_id=<?php echo $row['e_year_id'];?>"> Edit </a></button>
                                
								 <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['e_year_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['e_year_id'].'" id="delete"> Delete </button></td>
									<?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
							
							</tr>
						<?php
							}
						?>
						</tbody>
							
						</table>
					</div>
					</div>
				</div>
	</hr>

</div>
