<?php include 'template/header.php'; ?>

<?php
	include 'db_connect.php';
	

	$item = "SELECT `item_ref`,`item_description` FROM tbl_other_asset_info WHERE `other_asset_active_status` = 1 ORDER BY `item_description` asc";
	
	
	$result_item = $conn->query($item);
?>
	
  
  <?php
	
			
					if(isset($_POST['save']))
					{	 
						    
							$e_assert_type = $_POST['e_assert_type'];
							$e_2019 = $_POST['e_2019'];
							$e_2020 = $_POST['e_2020'];
							$e_2021 = $_POST['e_2021'];
							$e_2022 = $_POST['e_2022'];
							$e_2023 = $_POST['e_2023'];
							
							
							$sql = "INSERT INTO 
							           tbl_extra_assets
									   (e_assert_type,e_2019,e_2020,e_2021,e_2022,e_2023,e_active_status)
							
							VALUES ( 
							'".$e_assert_type."','".$e_2019."','".$e_2020."','".$e_2021."','".$e_2022."','".$e_2023."',1)";
							
							//$_SESSION['year_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
			?>
			

<form action="" method="POST">


<div class="container mt-6">
 
  <div class="row pt-2">
   <div class="col-sm-5"><font size="6px"><b>Other Assets</b></font></div>
  </div><br>
  
    <div class="row pt-2">
	    <div class="col-sm-2">
			<label for="e_assert_type" id="preinput">Asset Type</label>
		</div>
		
		<div class="col-sm-1">
		    <label for="e_assert_type" id="preinput">:</label>
		</div>
		
		<div class="col-sm-2">
				  <!--<select name="assert_service_agreement" style="width:220px; height:35px" class="form-control" id="assert_service_agreement">
				  <option value="select"></option>
				  <option value="supplier">Land</option>
				  <option value="contact">Building</option>
				  <option value="address">Passenger</option>
				  <option value="details">CGR</option>
				  <option value="supplier">P&N </option>
				  <option value="contact">Restaurant</option>
				  <option value="address">Juice Bar</option>
				  <option value="details">Bank</option>
				  <option value="details">Janitorial</option>
				  </select>-->
						  <?php
						  
						  ?>
				    <select name="e_assert_type" style="width:220px; height:35px" class="form-control" id="failure">
					  <option value="select"></option>
					  <?php 
						while($row = $result_item->fetch_assoc()) {
					  ?>
						<option value="<?php echo $row['item_ref'];?>">
						<?php echo $row['item_description'];?></option>
					  <?php
						}
					  ?>
					  
					</select>
		</div>
  </div>
  
  <div class="row pt-2">
		<div class="col-sm-2">
			<label for="e_2019" id="preinput">2019</label>
		</div>
		<div class="col-sm-1">
			<label for="e_2019" id="preinput">:</label>
		</div>			  
		<div class="col-sm-2">
			<input type="text" class="form-control" style="width:150px; height:40px;"  name="e_2019" id="inputid" >
		</div>
   </div>
   
    <div class="row pt-2">
		<div class="col-sm-2">
			<label for="e_2020" id="preinput">2020</label>
		</div>
		<div class="col-sm-1">
			<label for="e_2020" id="preinput">:</label>
		</div>			  
		<div class="col-sm-2">
			<input type="text" class="form-control" style="width:150px; height:40px;"  name="e_2020" id="inputid" >
		</div>
	</div>
	
	<div class="row pt-2">
		<div class="col-sm-2">
			<label for="e_2021" id="preinput">2021</label>
		</div>
		<div class="col-sm-1">
			<label for="e_2021" id="preinput">:</label>
		</div>			  
		<div class="col-sm-2">
			<input type="text" class="form-control" style="width:150px; height:40px;"  name="e_2021" id="inputid" >
		</div>
	</div>
	
	<div class="row pt-2">
		<div class="col-sm-2">
			<label for="e_2022" id="preinput">2022</label>
		</div>
		<div class="col-sm-1">
			<label for="e_2022" id="preinput">:</label>
		</div>			  
		<div class="col-sm-2">
			<input type="text" class="form-control" style="width:150px; height:40px;"  name="e_2022" id="inputid" >
		</div>
	</div>
	
	<div class="row pt-2">
		<div class="col-sm-2">
			<label for="e_2023" id="preinput">2023</label>
		</div>
		<div class="col-sm-1">
			<label for="e_2023" id="preinput">:</label>
		</div>			  
		<div class="col-sm-1">
			<input type="text" class="form-control" style="width:150px; height:40px;"  name="e_2023" id="inputid" ><br><br>
			<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;">Save</button>
		</div>
	</div>

  
</div>

</form>
<?php include 'template/footer.php'; ?>