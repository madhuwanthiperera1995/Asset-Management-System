  <?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var e_assert_type = $('#e_assert_type').val(); 
						var e_2019 = $('#e_2019').val();
						var e_2020 = $('#e_2020').val();
						var e_2021 = $('#e_2021').val(); 
						var e_2022 = $('#e_2022').val();
						var e_2023 = $('#e_2023').val();
						var click='TRUE';
			
			
			
			url='other_a_view.php?click=true&e_assert_type='+e_assert_type+'';
			//alert(url);
				
			$.ajax({
				url:'other_a_view.php?click=true&e_assert_type='+e_assert_type+'',
				type: 'GET',
				data: '&e_assert_type='+e_assert_type+'&e_2019='+e_2019+'&e_2020='+e_2020+'&e_2021='+e_2021+'&e_2022='+e_2022+'&e_2023='+e_2023+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
		



                       function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'other_asset_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  //alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }	

</script>					  




<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">
							<div class="container mt-5">
							  <div class="row pt-6"><center>
								</div><br>
								
							<div class="row pt-2">
										<label for="" id="preinput"><font size="6px"><center><b>Asset View</b></center></font></label>
							
							</div><br>

							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="e_assert_type" id="preinput">Asset Type</label>
										</div>
										<div class="col-sm-1">
											<label for="e_assert_type" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											
											  <select name="e_assert_type" id="e_assert_type" style="width:220px; height:35px" class="form-control">
												  <option value="0">select</option>
												  <option value="LVAL">Land Value</option>
												  <option value="BVAL">Building Value</option>
												  <option value="PCOUNT">Passenger Count</option>
												  <option value="CGRREV">CGR Revenue</option>
												  <option value="PNREV">P&N Revenue</option>
												  <option value="RESTAURANT">Restaurant</option>
												  <option value="JUICEBR">Juice Bar</option>
												  <option value="BANK">Bank</option>
												  <option value="JANITORIAL">Janitorial</option>
											  </select>
										</div>
							</div>
										
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="e_2019" id="preinput">2019</label>
										</div>
										<div class="col-sm-1">
											<label for="e_2019" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control"  name="e_2019" id="e_2019" >
										</div>
							</div>
							
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="e_2020" id="preinput">2020</label>
										</div>
										<div class="col-sm-1">
											<label for="e_2020" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="e_2020" id="e_2020" >
										</div>
							</div>
							
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="e_2021" id="preinput">2021</label>
										</div>
										<div class="col-sm-1">
											<label for="e_2021" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="e_2021" id="e_2021" >
										</div>
							</div>
							
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="e_2022" id="preinput">2022</label>
										</div>
										<div class="col-sm-1">
											<label for="e_2022" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="e_2022" id="e_2022" >
										</div>
							</div>
							
							<div class="row pt-2">
										<div class="col-sm-4"></div>
										<div class="col-sm-2">
										    <label for="e_2023" id="preinput">2023</label>
										</div>
										<div class="col-sm-1">
											<label for="e_2023" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" name="e_2023" id="e_2023" >
										</div>
							</div><br>

							
							<div class="row pt-2">
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
										
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
												
												<div class="col-sm-2"></div>
												
												<div class="col-sm-1" class="div1">
													<button name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
												</div>
												<div class="col-sm-2"></div>
										</div>
							</div>

</div>

</div>
<!-- </form> -->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>

