 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<?php include 'template/header.php'; ?>


<body>

<div class="container-fluid">
	


<div class="container mt-5">
							<div class="container mt-5">
							  <div class="row pt-6"><center>
								</div><br>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="assert_type" id="preinput">Assert Type</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_type" id="preinput">:</label>
										</div>
										<div class="col-sm-2">
											
											  <select name="assert_type" id="assert_type" style="width:170px; height:35px" class="form-control">
											  <option value="select"></option>
											  <option value="fixed">Fixed</option>
											  <option value="movable">Movable</option>
											  <option value="other">Other</option>
											  </select>
										</div>
										
										<div class="col-sm-2">
										<label for="item_code" id="preinput">Item Code</label>
										</div>
										<div class="col-sm-1">
											<label for="item_code" id="preinput">:</label>
										</div>
										<div class="col-sm-2">
											<input type="text" class="form-control" name="item_code" id="item_code" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="assert_category" id="preinput">Assert Category</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_category" id="preinput">:</label>
										</div>
										<div class="col-sm-2">
											
											  <select name="assert_category" id="assert_category" style="width:170px; height:35px" class="form-control">
											  <option value="select"></option>
											  <option value="consumer">Consumer</option>
											  <option value="electrical">Electrical</option>
											  <option value="electronic">Electronic</option>
											  <option value="furniture">Furniture</option>
											  <option value="maintenance">Maintenance</option>
											  <option value="motor">Motor</option>
											  <option value="removable">Removable</option>
											  <option value="other">Other</option>
											  </select>
										</div>
										
										<div class="col-sm-2">
										<label for="brand" id="preinput">Brand</label>
										</div>
										<div class="col-sm-1">
											<label for="brand" id="preinput">:</label>
										</div>
										<div class="col-sm-2">
											<input type="text" class="form-control" name="brand" id="brand" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="aasert_name" id="preinput">Assert Name</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_name" id="preinput">:</label>
										</div>
										<div class="col-sm-2" >
											<input type="text" style="width:170px; height:35px" class="form-control" name="assert_name" id="assert_name" >
										</div>
										
										<div class="col-sm-2">
										<label for="model" id="preinput">Model</label>
										</div>
										<div class="col-sm-1">
											<label for="model" id="preinput">:</label>
										</div>
										<div class="col-sm-2">
											<input type="text" class="form-control" name="model" id="model" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="location" id="preinput">Location</label>
										</div>
										<div class="col-sm-1">
											<label for="loction" id="preinput">:</label>
										</div>
										<div class="col-sm-2">
											  <select name="location" id="location" style="width:170px; height:35px" class="form-control">
											  <option value="select"></option>
											  <option value="cgr">CGR</option>
											  <option value="first_floor_a">First floor A side</option>
											  <option value="first_floor_b">First floor B side</option>
											  <option value="ground_floor_a">Ground floor A side</option>
											  <option value="ground_floor_b">Ground floor B side</option>
											  </select>
										</div>
										
									
							</div>

							<div class="row pt-2">
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
										
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
												
												<div class="col-sm-2"></div>
												
												<div class="col-sm-1" id="div1">
													<button  name="search" id="add_data" style="background-color:gray"><b>Search</b></button>
												</div>
												<div class="col-sm-2"></div>
										</div>
							</div>

</div>

<br>

<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">Assert Master View</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data-table">
						<thead>
							<tr>
								<th>Assert Type</th>
								<th>Assert Category</th>
								<th>Assert Name</th>
								<th>Item Code</th>
								<th>Brand</th>
								<th>Model</th>
								<th>Location</th>
								<th>Date of Production</th>
								<th>Warranty</th>
								<th>Edit/Delete/View</th>
							</tr>
						</thead>
						</table>
					</div>
					</div>
				</div>
	</hr>

</div>

</body>

<script type="text/javascript">
	$(function(){
		$('#add_data').click(function(){
			var assert_type = $('#assert_type').val();
			var assert_category = $('#assert_category').val();
			var assert_name = $('#assert_name').val();
			var item_code = $('#item_code').val();
			var brand = $('#brand').val();
			var model = $('#model').val();
			var location = $('#location').val();
			/*var assert_category = $('#completio').val();
			var location = $('#location').val();*/
			
			
		//insert inputs into table
		$('#data_table tbody:last-child').append(
		'<tr>'+
			'<td>'+assert_type+'</td>'+
			'<td>'+assert_category+'</td>'+
			'<td>'+assert_name+'</td>'+
			'<td>'+item_code+'</td>'+
			'<td>'+brand+'</td>'+
			'<td>'+model+'</td>'+
			'<td>'+location+'</td>'+
		'</td>'
		);
	});
</script>
</html>
