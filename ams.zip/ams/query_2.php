 
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
  <?php include 'template/header.php'; ?>
  
    
   <div class="container">
   <br />
   <form method="post" id="user_form">
    <div class="table-responsive">
     <table class="table table-striped table-bordered" id="user_data">
      <tr>
								<th>Assert Type</th>
								<th>Assert Category</th>
								<th>Assert Name</th>
								<th>Item Code</th>
								<th>Brand</th>
								<th>Model</th>
								<th>Location</th>
								<th>Date of Production</th>
								<th>Warranty</th>
								<th>Edit/Delete/View</th>
      </tr>
     </table>
	 
    </div>
    
   </form>

   <br />
  </div>
  
<div class="container mt-5">
							<div class="container mt-5">
							  <div class="row pt-6"><center>
								</div><br>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="assert_type" id="preinput">Assert Type</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_type" id="preinput">:</label>
										</div>
										<div class="col-sm-2" id="div1">
											
											  <select name="assert_type" id="assert_type" style="width:170px; height:35px" class="form-control">
											  <option value="select"></option>
											  <option value="fixed">Fixed</option>
											  <option value="movable">Movable</option>
											  <option value="other">Other</option>
											  </select>
										</div>
										
										<div class="col-sm-2">
										<label for="item_code" id="preinput">Item Code</label>
										</div>
										<div class="col-sm-1">
											<label for="item_code" id="preinput">:</label>
										</div>
										<div class="col-sm-2" id="div1">
											<input type="text" class="form-control" name="item_code" id="item_code" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="assert_category" id="preinput">Assert Category</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_category" id="preinput">:</label>
										</div>
										<div class="col-sm-2" id="div1">
											
											  <select name="assert_category" id="assert_category" style="width:170px; height:35px" class="form-control">
											  <option value="select"></option>
											  <option value="consumer">Consumer</option>
											  <option value="electrical">Electrical</option>
											  <option value="electronic">Electronic</option>
											  <option value="furniture">Furniture</option>
											  <option value="maintenance">Maintenance</option>
											  <option value="motor">Motor</option>
											  <option value="removable">Removable</option>
											  <option value="other">Other</option>
											  </select>
										</div>
										
										<div class="col-sm-2">
										<label for="brand" id="preinput">Brand</label>
										</div>
										<div class="col-sm-1">
											<label for="brand" id="preinput">:</label>
										</div>
										<div class="col-sm-2" id="div1">
											<input type="text" class="form-control" name="brand" id="brand" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="aasert_name" id="preinput">Assert Name</label>
										</div>
										<div class="col-sm-1">
											<label for="assert_name" id="preinput">:</label>
										</div>
										<div class="col-sm-2" id="div1">
											<input type="text" style="width:170px; height:35px" class="form-control" name="assert_name" id="assert_name" >
										</div>
										
										<div class="col-sm-2">
										<label for="model" id="preinput">Model</label>
										</div>
										<div class="col-sm-1">
											<label for="model" id="preinput">:</label>
										</div>
										<div class="col-sm-2" id="div1">
											<input type="text" class="form-control" name="model" id="model" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="location" id="preinput">Location</label>
										</div>
										<div class="col-sm-1">
											<label for="loction" id="preinput">:</label>
										</div>
										<div class="col-sm-2" id="div1">
											  <select name="location" id="location" style="width:170px; height:35px" class="form-control">
											  <option value="select"></option>
											  <option value="cgr">CGR</option>
											  <option value="first_floor_a">First floor A side</option>
											  <option value="first_floor_b">First floor B side</option>
											  <option value="ground_floor_a">Ground floor A side</option>
											  <option value="ground_floor_b">Ground floor B side</option>
											  </select>
										</div>
										
									
							</div>

							<div class="row pt-2">
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
										
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
												
										<div class="col-sm-2"></div>
												
										<div class="col-sm-1" id="div1">
													<button  name="search" id="search" style="background-color:gray"><b>Search</b></button>
										</div>
										<div class="col-sm-2"></div>
							</div>
							
					</div>

</div>


   
<?php include 'template/footer.php'; ?> 

<script>  
$(document).ready(function(){ 
 
 var count = 0;

 $('#search').click(function(){
            var assert_type = $('#assert_type').val(); 
			var assert_category = $('#assert_category').val();
			var assert_name = $('#assert_name').val();
			var item_code = $('#item_code').val(); 
			var brand = $('#brand').val();
			var model = $('#model').val();
			var location = $('#location').val(); 
 });

 $('#save').click(function(){
  var assert_type = '';
  var assert_category = '';
  var assert_name = '';
  var item_code = '';
  var brand = '';
  var model = '';
  var location = '';
 
  if(error_first_name != '' || error_last_name != '')
  {
   return false;
  }
  else
  {
   if($('#save').text() == 'Save')
   {
    count = count + 1;
    output = '<tr id="row_'+count+'">';
    output += '<td>'+first_name+' <input type="hidden" name="hidden_first_name[]" id="first_name'+count+'" class="first_name" value="'+first_name+'" /></td>';
    output += '<td>'+last_name+' <input type="hidden" name="hidden_last_name[]" id="last_name'+count+'" value="'+last_name+'" /></td>';
    output += '<td><button type="button" name="view_details" class="btn btn-warning btn-xs view_details" id="'+count+'">View</button></td>';
    output += '<td><button type="button" name="remove_details" class="btn btn-danger btn-xs remove_details" id="'+count+'">Remove</button></td>';
    output += '</tr>';
    $('#user_data').append(output);
   }
   else
   {
    var row_id = $('#hidden_row_id').val();
    output = '<td>'+first_name+' <input type="hidden" name="hidden_first_name[]" id="first_name'+row_id+'" class="first_name" value="'+first_name+'" /></td>';
    output += '<td>'+last_name+' <input type="hidden" name="hidden_last_name[]" id="last_name'+row_id+'" value="'+last_name+'" /></td>';
    output += '<td><button type="button" name="view_details" class="btn btn-warning btn-xs view_details" id="'+row_id+'">View</button></td>';
    output += '<td><button type="button" name="remove_details" class="btn btn-danger btn-xs remove_details" id="'+row_id+'">Remove</button></td>';
    $('#row_'+row_id+'').html(output);
   }

   $('#user_dialog').dialog('close');
  }
 });

 $(document).on('click', '.view_details', function(){
  var row_id = $(this).attr("id");
  var first_name = $('#first_name'+row_id+'').val();
  var last_name = $('#last_name'+row_id+'').val();
  $('#first_name').val(first_name);
  $('#last_name').val(last_name);
  $('#save').text('Edit');
  $('#hidden_row_id').val(row_id);
  $('#user_dialog').dialog('option', 'title', 'Edit Data');
  $('#user_dialog').dialog('open');
 });

 $(document).on('click', '.remove_details', function(){
  var row_id = $(this).attr("id");
  if(confirm("Are you sure you want to remove this row data?"))
  {
   $('#row_'+row_id+'').remove();
  }
  else
  {
   return false;
  }
 });

 $('#action_alert').dialog({
  autoOpen:false
 });

 $('#user_form').on('submit', function(event){
  event.preventDefault();
  var count_data = 0;
  $('.first_name').each(function(){
   count_data = count_data + 1;
  });
  if(count_data > 0)
  {
   var form_data = $(this).serialize();
   $.ajax({
    url:"insert.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     $('#user_data').find("tr:gt(0)").remove();
     $('#action_alert').html('<p>Data Inserted Successfully</p>');
     $('#action_alert').dialog('open');
    }
   })
  }
  else
  {
   $('#action_alert').html('<p>Please Add atleast one data</p>');
   $('#action_alert').dialog('open');
  }
 });
 
});  
</script>



