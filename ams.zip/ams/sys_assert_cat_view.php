<?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var category_name = $('#category_name').val(); 
						var category_code = $('#category_code').val();
						var category_description = $('#category_description').val();
						var click='TRUE';
			
			
			url='sys_cat_view.php?click=true&category_name='+category_name+'&category_code='+category_code+'&category_description='+category_description+'';
			//alert(url);
				
			$.ajax({
				url:'sys_cat_view.php?click=true&category_name='+category_name+'&category_code='+category_code+'&category_description='+category_description+'',
				type: 'GET',
				data: '&category_name='+category_name+'&category_code='+category_code+'&category_description='+category_description+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
	
					function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'category_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }		

					

</script>

<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Assert Category View</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_name" id="preinput">Category Name</label>
			</div>
			<div class="col-sm-1">
				<label for="category_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_name" id="category_name">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_code" id="preinput">Category Code</label>
			</div>
			<div class="col-sm-1">
				<label for="category_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_code" id="category_code">
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_description" id="preinput">Category Description</label>
			</div>
			<div class="col-sm-1">
				<label for="category_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_description" id="category_description">
			</div>
		</div><br>
		
		<div class="row pt-2">
			<div class="col-sm-3"></div>
			<div class="col-sm-2"></div>
			<div class="col-sm-1"></div>
			<div class="col-sm-2" class="div1">
				<button type="search" name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
			</div>
		</div>
		
</div>

</div>
<!--</form>-->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>