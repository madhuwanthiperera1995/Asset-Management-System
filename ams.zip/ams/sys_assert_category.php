<?php include 'template/header.php'; ?>

<?php
	include 'db_connect.php';
?>

<?php
				if(isset($_POST['save']))
					{	 
						    
							$category_name = $_POST['category_name'];
							$category_code = $_POST['category_code'];
							$category_description = $_POST['category_description'];
							
							
							$sql = "INSERT INTO tbl_sys_assert_category(
							category_name,category_code,category_description)
							
							VALUES ( 
							'".$category_name."','".$category_code."','".$category_description."')";
							
							//$_SESSION['sys_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
?>

<form action="" method="POST">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Assert Category</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_name" id="preinput">Category Name</label>
			</div>
			<div class="col-sm-1">
				<label for="category_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_name" id="inputid">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_code" id="preinput">Category Code</label>
			</div>
			<div class="col-sm-1">
				<label for="category_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_code" id="inputid">
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_description" id="preinput">Category Description</label>
			</div>
			<div class="col-sm-1">
				<label for="category_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_description" id="inputid"><br><br>
				<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;"><b>ADD</b></button>
			</div>
		</div>
		
</div>
</form>
<?php include 'template/footer.php'; ?>