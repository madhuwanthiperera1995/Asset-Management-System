<!--<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>-->	

<?php

	include 'template/header.php';
//echo 'jkjkjk '.$_SESSION['user_level'].'...........mmaadddddddd ';
	if((isset($_SESSION['user_level'])) && (($_SESSION['user_level']=='1') || ($_SESSION['user_level']=='2')))
	{	

    include 'db_connect.php';
	
	$sys_assert_cat_id = $_GET['sys_assert_cat_id'];
	
	$edit = "SELECT
				*FROM
				  tbl_sys_assert_category
				WHERE
				  `sys_assert_cat_id`= '".$_GET['sys_assert_cat_id']."'";
				  
	$result_ed = $conn->query($edit);
	
	$row = mysqli_fetch_array($result_ed);
	
	if(isset($_POST['update'])) // when click on Update button
{
						    $category_name = $_POST['category_name'];
							$category_code = $_POST['category_code'];
							$category_description = $_POST['category_description'];
			
	 $new1 = "UPDATE 
				tbl_sys_assert_category 
					SET 
						category_name = '$category_name', category_code='$category_code', category_description='$category_description'
					WHERE 
						sys_assert_cat_id = '$sys_assert_cat_id'";
							
  

                        if (mysqli_query($conn, $new1)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $new1 . "
					" . mysqli_error($conn);
						 }
						 

                if($new1)
					{
						mysqli_close($conn); // Close connection
						header("location:sys_assert_cat_view.php"); // redirects to all records page
						exit;
					}
					else
					{
						echo mysqli_error();
					}    							 
}

?>

<form action="" method="POST">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Assert Category</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_name" id="preinput">Category Name</label>
			</div>
			<div class="col-sm-1">
				<label for="category_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_name" id="category_name" value="<?php echo $row['category_name'] ?>">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_code" id="preinput">Category Code</label>
			</div>
			<div class="col-sm-1">
				<label for="category_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_code" id="category_code" value="<?php echo $row['category_code'] ?>">
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="category_description" id="preinput">Category Description</label>
			</div>
			<div class="col-sm-1">
				<label for="category_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="category_description" id="category_description" value="<?php echo $row['category_description'] ?>"><br><br>
				<button type="update" name="update" style="background-color:gray;">Update</button>
			</div>
		</div>
		
</div>
</form>
 <?php
	}
	else{
		echo "You do not have access to this page... Please contact admin or manager";
		?>
		<button type="home" name="home" style="background-color:gray"><a href="home_page.php">Home</a></button>
		<button type="back" name="back" style="background-color:gray"><a href="user_view.php">Back</a></button>
		<?php
	}
	
  ?>
	
</body>
</html>
