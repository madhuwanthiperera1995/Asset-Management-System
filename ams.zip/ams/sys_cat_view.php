
			<?php 
			session_start();
			include 'db_connect.php';
			
			if(isset($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';

					$category_name = $_GET['category_name'];
					$category_code = $_GET['category_code'];
					$category_description = $_GET['category_description'];
					
					$filter = "1=1";
					
					        if(isset($_GET['sys_assert_cat_id']) && ($_GET['sys_assert_cat_id']!='0'))
							{
								$filter .= " AND `sys_assert_cat_id` LIKE '%".$_GET['sys_assert_cat_id']."%'";
								
							}
					
							if(isset($_GET['category_name']) && ($_GET['category_name']!='%'))
							{
								$filter .= " AND `category_name` LIKE '%".$_GET['category_name']."%'";
								
							}
							
							if(isset($_GET['category_code']) && ($_GET['category_code']!=''))
							{
								$filter .= " AND `category_code` LIKE '%".$_GET['category_code']."%'";
							}
								
							if(isset($_GET['category_description']) && ($_GET['category_description']!=''))
							{
								$filter .= " AND `category_description` LIKE '%".$_GET['category_description']."%'";
							}
					
						
			    $view_z = "SELECT 
					            `sys_assert_cat_id`,`category_name`,`category_code`,`category_description`
							   FROM 
							     tbl_sys_assert_category 
							   WHERE 
							     $filter";
								 
						//echo '2222';
						
					       $result = $conn->query($view_z);
			}
			
			else{
				echo "Invalid Calling Method!";
				
			}
			
			//echo 'mklslkfjsafj';
			
?> 
			

			
<div class="container">
   <br />
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">Assert Category View</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
							    <th>ID</th>
								<th>Category Name</th>
								<th>Category Code</th>
								<th>Category Description</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
								
						?>
						
							<tr>
							    <td><?php echo $row['sys_assert_cat_id']; ?></td>
								<td><?php echo $row['category_name']; ?></td>
								<td><?php echo $row['category_code']; ?></td>
								<td><?php echo $row['category_description']; ?></td>
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['sys_assert_cat_id'].'" id="edit"><a href="sys_cat_edit.php?sys_assert_cat_id=<?php echo $row['sys_assert_cat_id'];?>"> Edit </a></button>
                                  <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['sys_assert_cat_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['sys_assert_cat_id'].'" id="delete"> Delete </button></td>
								<?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
							
							</tr>
						<?php
							}
						?>
						</tbody>
						
						</table>
					</div>
					</div>
				</div>
	</hr>

</div> 
