<!--<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>	-->

<?php

include 'template/header.php';
//echo 'jkjkjk '.$_SESSION['user_level'].'...........mmaadddddddd ';
	if((isset($_SESSION['user_level'])) && (($_SESSION['user_level']=='1') || ($_SESSION['user_level']=='2')))
	{		  
 
    include 'db_connect.php';
	
	$sys_id = $_GET['sys_id'];
	
	$edit = "SELECT
				*FROM
				  tbl_sys_setting
				WHERE
				  `sys_id`= '".$_GET['sys_id']."'";
				  
	$result_ed = $conn->query($edit);
	
	$row = mysqli_fetch_array($result_ed);
	
	if(isset($_POST['update'])) // when click on Update button
{
						    $sys_multimodal_center = $_POST['sys_multimodal_center'];
							$sys_short_code = $_POST['sys_short_code'];
							$sys_no_terminals = $_POST['sys_no_terminals'];
							$sys_address = $_POST['sys_address'];
							$sys_city = $_POST['sys_city'];
							$sys_tel_no = $_POST['sys_tel_no'];
							$sys_fax = $_POST['sys_fax'];
							$sys_web = $_POST['sys_web'];
							$sys_email = $_POST['sys_email'];
	
	 $new1 = "UPDATE 
				tbl_sys_setting 
					SET 
						sys_multimodal_center = '$sys_multimodal_center', sys_short_code='$sys_short_code', sys_no_terminals='$sys_no_terminals', 
						sys_address='$sys_address', sys_city='$sys_city',sys_tel_no='$sys_tel_no', sys_fax='$sys_fax', sys_web='$sys_web', 
						sys_email='$sys_email'
					WHERE 
						sys_id = '$sys_id'";
							
  

                        if (mysqli_query($conn, $new1)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $new1 . "
					" . mysqli_error($conn);
						 }
						 

                if($new1)
					{
						mysqli_close($conn); // Close connection
						header("location:sys_setting_view.php"); // redirects to all records page
						exit;
					}
					else
					{
						echo mysqli_error();
					}    							 
}

?>

<form action="" method="POST">

<div class="container mt-5">

 
  <div class="row pt-2">
   <div class="col-sm-12"><font size="6px"><b>Assert Management System- (Location) Multi Modal Center</b></font></div>
  </div><br>
  
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_multimodal_center" id="preinput">Multimodal Center</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_multimodal_center" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="sys_multimodal_center" id="sys_multimodal_center" style="width:170px; height:35px" class="form-control" value="<?php echo $row['sys_multimodal_center'] ?>">
				  <option value="select" <?php if($row['sys_multimodal_center']== 'select'){ echo 'selected'; }?>></option>
				  <option value="200" <?php if($row['sys_multimodal_center']== '200'){ echo 'selected'; }?>>Kottawa</option>
				  <option value="201" <?php if($row['sys_multimodal_center']== '201'){ echo 'selected'; }?>>Kadawatha</option>
				  <option value="202" <?php if($row['sys_multimodal_center']== '202'){ echo 'selected'; }?>>Kandy</option>
				  </select>
			</div>
	    </div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_short_code" id="preinput">Short Code</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_short_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_short_code" id="inputid" value="<?php echo $row['sys_short_code']; ?>">
			</div>
		</div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_no_terminals" id="preinput">No. of Terminals</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_no_terminals" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_no_terminals" id="inputid" value="<?php echo $row['sys_no_terminals']; ?>">
			</div>
		</div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_address" id="preinput">Address</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_address" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_address" id="inputid" value="<?php echo $row['sys_address']; ?>">
			</div>
		</div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_city" id="preinput">City</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_city" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_city" id="inputid" value="<?php echo $row['sys_city']; ?>">
			</div>
		</div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_tel_no" id="preinput">Telephone No.</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_tel_no" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_tel_no" id="inputid" value="<?php echo $row['sys_tel_no']; ?>">
			</div>
		</div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_fax" id="preinput">Fax No.</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_fax" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_fax" id="inputid" value="<?php echo $row['sys_fax']; ?>">
			</div>
		</div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_web" id="preinput">Web</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_web" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_web" id="inputid" value="<?php echo $row['sys_web']; ?>">
			</div>
		</div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_email" id="preinput">Email</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_email" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="sys_email" id="inputid" value="<?php echo $row['sys_email']; ?>"><br><br>
				<button type="update" name="update" style="background-color:gray; width:100px; height:40px;">Update</button>
			</div>
		</div>
		
</div>
</form>
 <?php
	}
	else{
		echo "You do not have access to this page... Please contact admin or manager";
		?>
		<button type="home" name="home" style="background-color:gray"><a href="home_page.php">Home</a></button>
		<button type="back" name="back" style="background-color:gray"><a href="user_view.php">Back</a></button>
		<?php
	}
	
  ?>
	
</body>
</html>

