<?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var sys_multimodal_center = $('#sys_multimodal_center').val(); 
						var sys_short_code = $('#sys_short_code').val();
						var sys_city = $('#sys_city').val();
						var sys_email = $('#sys_email').val(); 
						var sys_no_terminals = $('#sys_no_terminals').val();
						var sys_address = $('#sys_address').val();
						var click='TRUE';
			
			
			url='sys_view.php?click=true&sys_multimodal_center='+sys_multimodal_center+'';
			//alert(url);
				
			$.ajax({
				url:'sys_view.php?click=true&sys_multimodal_center='+sys_multimodal_center+'',
				type: 'GET',
				data: '&sys_multimodal_center='+sys_multimodal_center+'&sys_short_code='+sys_short_code+'&sys_city='+sys_city+'&sys_email='+sys_email+'&sys_no_terminals='+sys_no_terminals+'&sys_address='+sys_address+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
	
				function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'sys_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }		

					

</script>




<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">

 
  <div class="row pt-2">
   <div class="col-sm-12"><font size="6px"><b><center>MMC Information View</center></b></font></div>
  </div><br>
  
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_multimodal_center" id="preinput">Multimodal Center</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_multimodal_center" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				  <select name="sys_multimodal_center" id="sys_multimodal_center" style="width:170px; height:35px" class="form-control">
				  <option value="0">Select</option>
				  <option value="201">Kadawatha</option>
				  <option value="202">Kandy</option>
				  <option value="200">Kottawa</option>
				  </select>
				  
			</div>
			
			<div class="col-sm-2">
				<label for="sys_short_code" id="preinput">Short Code</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_short_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:170px; height:35px" name="sys_short_code" id="sys_short_code">
			</div>
			
	    </div>
		
		<div class="row pt-2">
			<div class="col-sm-2">
				<label for="sys_city" id="preinput">City</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_city" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:170px; height:35px" name="sys_city" id="sys_city">
			</div>
			
			<div class="col-sm-2">
				<label for="sys_email" id="preinput">Email</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_email" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:170px; height:35px" name="sys_email" id="sys_email">
			</div>
			
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-2">
				<label for="sys_no_terminals" id="preinput">No. of Terminals</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_no_terminals" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:170px; height:35px" name="sys_no_terminals" id="sys_no_terminals">
			</div>
			
			<div class="col-sm-2">
				<label for="sys_address" id="preinput">Address</label>
			</div>
			<div class="col-sm-1">
				<label for="sys_address" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:170px; height:35px" name="sys_address" id="sys_address"><br><br>
				<button name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
			</div>
			
		</div>
		
</div>

</div>
<!--</form>-->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>