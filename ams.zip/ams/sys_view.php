
			<?php 
			session_start();
			include 'db_connect.php';
			
			if(isset($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';

					$sys_multimodal_center = $_GET['sys_multimodal_center'];
					$sys_short_code = $_GET['sys_short_code'];
					$sys_city = $_GET['sys_city'];
					$sys_email = $_GET['sys_email'];
					$sys_no_terminals = $_GET['sys_no_terminals'];
					$sys_address = $_GET['sys_address'];
					
					$filter = "1=1";
					
					        if(isset($_GET['sys_id']) && ($_GET['sys_id']!='0'))
							{
								$filter .= " AND `sys_id` LIKE '%".$_GET['sys_id']."%'";
								
							}
					
							if(isset($_GET['sys_multimodal_center']) && ($_GET['sys_multimodal_center']!='0'))
							{
								$filter .= " AND `sys_multimodal_center` = '".$_GET['sys_multimodal_center']."'";
								
							}
							
							if(isset($_GET['sys_short_code']) && ($_GET['sys_short_code']!=''))
							{
								$filter .= " AND `sys_short_code` LIKE '%".$_GET['sys_short_code']."%'";
							}
								
							if(isset($_GET['sys_city']) && ($_GET['sys_city']!=''))
							{
								$filter .= " AND `sys_city` LIKE '%".$_GET['sys_city']."%'";
							}
							
							if(isset($_GET['sys_email']) && ($_GET['sys_email']!=''))
							{
								$filter .= " AND `sys_email` LIKE '%".$_GET['sys_email']."%'";
							}
								 
							
							if(isset($_GET['sys_no_terminals']) && ($_GET['sys_no_terminals']!=''))
							{
								$filter .= " AND `sys_no_terminals` LIKE '%".$_GET['sys_no_terminals']."%'";
							}
							
							if(isset($_GET['sys_address']) && ($_GET['sys_address']!='0'))
							{
								$filter .= " AND `sys_address` LIKE '%".$_GET['sys_address']."%'";
							}
							
							if(isset($_GET['sys_tel_no']) && ($_GET['sys_tel_no']!=''))
							{
								$filter .= " AND `sys_tel_no` LIKE '%".$_GET['sys_tel_no']."%'";
							}
							
							if(isset($_GET['sys_fax']) && ($_GET['sys_fax']!=''))
							{
								$filter .= " AND `sys_fax` LIKE '%".$_GET['sys_fax']."%'";
							}
					
						
			      $view_sys = "SELECT 
					            `sys_id`,`sys_multimodal_center`,`sys_short_code`,`sys_city`,`sys_email`,`sys_no_terminals`,`sys_address`,`sys_tel_no`,
								`sys_fax`
							   FROM 
							     tbl_sys_setting 
							   WHERE 
							     $filter";
								 
						//echo '2222';
						
					       $result = $conn->query($view_sys);
			}
			
			else{
				echo "Invalid Calling Method!";
				
			}
			
			//echo 'mklslkfjsafj';
			
?> 
			

			
<div class="container">
   <br />
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">System Setting</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
							    <th>ID</th>
								<th>Multimodal Center</th>
								<th>Short Code</th>
								<th>City</th>
								<th>Email</th>
								<th>No.of Terminals</th>
								<th>Address</th>
								<th>Tel. No</th>
								<th>Fax No.</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
								
						?>
						
							<tr>
							    <td><?php echo $row['sys_id']; ?></td>
								<td><?php echo $row['sys_multimodal_center']; ?></td>
								<td><?php echo $row['sys_short_code']; ?></td>
								<td><?php echo $row['sys_city']; ?></td>
								<td><?php echo $row['sys_email']; ?></td>
								<td><?php echo $row['sys_no_terminals']; ?></td>
								<td><?php echo $row['sys_address']; ?></td>
								<td><?php echo $row['sys_tel_no']; ?></td>
								<td><?php echo $row['sys_fax']; ?></td>
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['sys_id'].'" id="edit"><a href="sys_edit.php?sys_id=<?php echo $row['sys_id'];?>"> Edit </a></button>
                                 <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['sys_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['sys_id'].'" id="delete"> Delete </button></td>
								<?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
							
							
							</tr>
						<?php
							}
						?>
						</tbody>
						
						</table>
					</div>
					</div>
				</div>
	</hr>

</div> 
