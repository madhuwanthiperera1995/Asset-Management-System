<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  
<style>
        #nav {
            
            margin: 0;
            padding: 0;
            
        }

        #nav li {
            display: block;
            position: relative;
            float: left;
            background: #9B9B9C;
            /* menu background color */
        }

		#nav li a {
            display: block;
            text-decoration: none;
            width: 185px;
            /* this is the width of the menu items */
            line-height: 35px;
            /* this is the hieght of the menu items */
            color: #000000;
            /* list item font color */
        }
		
        #nav li li a {
            font-size: 90%;
        }

        /* smaller font size for sub menu items */

        #nav li:hover {
            background: #9B9B9C;
        }

        /* highlights current hovered list item and the parent list items when hovering over sub menues */

        #nav ul {
            position: absolute;
            padding: 0;
            left: 0;
            display: none;
            /* hides sublists */
        }

        #nav li:hover ul ul {
            display: none;
        }

        /* hides sub-sublists */

        #nav li:hover ul {
            display: block;
        }

        /* shows sublist on hover */

        #nav li li:hover ul {
            display: block;
            /* shows sub-sublist on hover */
            margin-left: 185px;
            /* this should be the same width as the parent list item */
            margin-top: -35px;
            /* aligns top of sub menu with top of list item */
        }
		
		#menu-bar
		{
			background: rgb(0,100,0);
			text-align: center;
		}
</style>
  
  
 <script>
 
function confirmact(txt)
{
alert(txt)
}
 	
	function confirmact() {
        let confirmact = confirm("Are you want to logout?");
		
        if (confirmact) {
          alert("Successfully Logout");
		  location.replace("user_loging.php")
		} 
         else {
          alert("Logout canceled");
		  location.replace("home_page.php")
        }
      }
	
 </script>
  

</head>
<body>

				<?php
							
							if(isset($_POST['logout']))
							{	 
							

							include 'logout.php';
							
							
							/*logout*/
							$qry =  $conn -> real_escape_string($logout);
																		
							$sql = "INSERT INTO tbl_activity_log (`user_id`,`module`,`activity`,`description`,`query`,`date`,`time`,`ip_address`) 
										values ('".$_session['user_id']."','user','Logout','Successfull Logout','".$qry."',
										NOW(),NOW(), '".$_SERVER['REMOTE_ADDR']."')" ;
																					
							$sql_query = $conn->query($sql);
							
							if($sql){
								session_start();}
								session_destroy();{
								  
								unset($_SESSION["user_id"]);
								header("Location: user_loging.php");
								
								}
							}
							
						?>
						
						<?php
						 
							class log
							{  
								CONST ENVIRONMENT = 'development';

								private $act_id;
								private $user_id;
								protected $module;
								protected $activity;
								protected $description;
								protected $query;
								protected $ip_address;
								protected $date;
								protected $time;
								

								public function __construct(string $module, string $activity, string $description, string $query)
								{
									if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
										$ip_address = $_SERVER['HTTP_CLIENT_IP'];
									} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
										$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
									} else {
										$ip_address = $_SERVER['REMOTE_ADDR'];
									}
									
									if(!empty($_SESSION['user_id'])){
										$user_id = $_SESSION['user_id'];
									}else {
										  $id = 0;
										  }
									$this->user_id = $user_id;
									$this->module = $module;
									$this->activity = $activity;
									$this->description = $description;
									$this->query = $query;
									$this->ip_address = $ip_address;
								}

								public function createAction()
								{
									global $conn;

									if(!$conn) {
									   echo mysqli_error($conn); die;
									}

									if(!$sql_query){
										echo mysqli_error($conn); die;
									}

									if(ENVIRONMENT == 'development'){
										$_SESSION['msg'] = 'User Logout ' . $this->act_id;
									}
									
								} }

						
						?>
											


<div class="container-fluid pt-3 bg-primary text-white text ali-left">
  <center><h1><font color="black" size="50px"><b>Makumbura Multi Modal Center - Kottawa</b></font></h1></center>
</div>
<nav class="navbar navbar-expand-sm">

  <div class="container-fluid">
	<div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav" id="nav">
			   <li class="nav-item">
				  <a class="nav-link" href="home_page.php"><center>Home</center></a>
				</li>
				 
				<li class="nav-item dropdown">
					  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">User Registration</a>
					  <ul class="dropdown-menu">
						<li><a class="dropdown-item" href="add_user.php">Add User</a></li>
						<li><a class="dropdown-item" href="user_view.php">View</a></li>
					  </ul>
				</li>
				
				 <li class="nav-item dropdown">
					  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Checklist</a>
					  <ul class="dropdown-menu">
						<li><a class="dropdown-item" href="checklist.php">Add</a></li>
						<li><a class="dropdown-item" href="checklist_view.php">View</a></li>
					  </ul>
				</li>
						
				<li class="nav-item dropdown">
					  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Incident</a>
					  <ul class="dropdown-menu">
						<li><a class="dropdown-item" href="incident.php">Add</a></li>
						<li><a class="dropdown-item" href="incident_view.php">View</a></li>
					  </ul>
				</li>
					
				<li class="nav-item dropdown">
					  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Breakdown</a>
					  <ul class="dropdown-menu">
						<li><a class="dropdown-item" href="breakdown.php">Add</a></li>
						<li><a class="dropdown-item" href="breakdown_view.php">View</a></li>
					  </ul>
				</li>
				
				<li class="nav-item dropdown">
					  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Asset Master</a>
					  <ul class="dropdown-menu">
						<li><a class="dropdown-item" href="assert_master.php">Add</a></li>
						<li><a class="dropdown-item" href="assert_master_view.php">View</a></li>
					  </ul>
				</li>
						
				<li class="nav-item dropdown">
					  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Sys Settings</a>
					  <ul class="dropdown-menu">
					           <li><a class="dropdown-item" href="#">MMC Information</a>
							        <ul class="dropdown-menu">
										<li><a class="dropdown-item" href="sys_setting.php">Add</a></li>
										<li><a class="dropdown-item" href="sys_setting_view.php">View</a></li>
									</ul>
							   </li>
								
								<li><a class="dropdown-item" href="#">Zone Information</a>
									<ul class="dropdown-menu">
										<li><a class="dropdown-item" href="zone_info.php">Add</a></li>
										<li><a class="dropdown-item" href="zone_view.php">View</a></li>
									</ul>
								</li>
								
								<li><a class="dropdown-item" href="#">Asset Category</a>
									<ul class="dropdown-menu">
										<li><a class="dropdown-item" href="sys_assert_category.php">Add</a></li>
										<li><a class="dropdown-item" href="sys_assert_cat_view.php">View</a></li>
									</ul>
								</li>
								
								<li><a class="dropdown-item" href="#">Unit of Measure</a>
									<ul class="dropdown-menu">
										<li><a class="dropdown-item" href="unit_of_measure.php">Add</a></li>
										<li><a class="dropdown-item" href="unit_of_measure_view.php">View</a></li>
									</ul>
								</li>
								
								<li><a class="dropdown-item" href="#">Other Assets</a>
									<ul class="dropdown-menu">
										<li><a class="dropdown-item" href="other_assets_add.php">Add</a></li>
										<li><a class="dropdown-item" href="other_assets_view.php">View</a></li>
									</ul>
								</li>
						
					  </ul>
				</li>
				
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				<ul></ul>
				
				<li class="nav-item">
					 <button onclick="confirmact()" value="Submit" style="background-color:green" type="logout" name="logout"><a class="nav-link"><font color="black"><b>Logout</b></font></a></button>
				</li> 
					 
			</ul>				

		</div>
	</div>
</nav>

<div class="row pt-2">
	<div class="col-sm-10">
	</div>
	<div class="col-sm-2">
		<b>
		<?php

		echo "Hello  " .''. $_SESSION['user_full_nm'];
		?>
		</b>
	</div>	
</div>


					    