
			<?php 
			session_start();
			include 'db_connect.php';
			
			if(isset($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';

					$user_category = $_GET['user_category'];
					$user_company_id = $_GET['user_company_id'];
					$user_position = $_GET['user_position'];
					$user_mobile = $_GET['user_mobile'];
					$user_address = $_GET['user_address'];
					$user_institute = $_GET['user_institute'];
					$user_nic_no = $_GET['user_nic_no'];
					//$completion_date = $_POST['completion_date'];
					//$assert_warranty_period = $_POST['assert_warranty_period'];
					
					/*echo "assert_type : ".$assert_type;
					echo "assert_category: ".$assert_category;
					echo "assert_name : ".$assert_name;
					echo "item_code : ".$item_code;
					echo "brand: ".$brand;
					echo "model : ".$model;
					echo "location : ".$location;
					echo "completion_date: ".$completion_date;
					echo "assert_warranty_period : ".$assert_warranty_period;*/
					
					$filter = "1=1";
					
					        if(isset($_GET['user_id']) && ($_GET['user_id']!='0'))
							{
								$filter .= " AND `user_id` LIKE '%".$_GET['user_id']."%'";
								
							}
					
							if(isset($_GET['user_category']) && ($_GET['user_category']!='0'))
							{
								$filter .= " AND `user_category` = '".$_GET['user_category']."'";
								
							}
							
							if(isset($_GET['user_company_id']) && ($_GET['user_company_id']!=''))
							{
								$filter .= " AND `user_company_id` LIKE '%".$_GET['user_company_id']."%'";
							}
								
							if(isset($_GET['user_position']) && ($_GET['user_position']!=''))
							{
								$filter .= " AND `user_position` LIKE '%".$_GET['user_position']."%'";
							}
							
							if(isset($_GET['user_mobile']) && ($_GET['user_mobile']!=''))
							{
								$filter .= " AND `user_mobile` LIKE '%".$_GET['user_mobile']."%'";
							}
								 
							
							if(isset($_GET['user_address']) && ($_GET['user_address']!=''))
							{
								$filter .= " AND `user_address` LIKE '%".$_GET['user_address']."%'";
							}
							
							if(isset($_GET['user_institute']) && ($_GET['user_institute']!='0'))
							{
								$filter .= " AND `user_institute` = '".$_GET['user_institute']."'";
							}
							
							if(isset($_GET['user_nic_no']) && ($_GET['user_nic_no']!=''))
							{
								$filter .= " AND `user_nic_no` LIKE '%".$_GET['user_nic_no']."%'";
							}
							
							if(isset($_GET['user_full_name']) && ($_GET['user_full_name']!=''))
							{
								$filter .= " AND `user_full_name` LIKE '%".$_GET['user_full_name']."%'";
							}
							
							if(isset($_GET['user_email']) && ($_GET['user_email']!=''))
							{
								$filter .= " AND `user_email` LIKE '%".$_GET['user_email']."%'";
							}
					
						
					$view_u = "SELECT 
					            `user_id`,`user_category`,`user_company_id`,`user_position`,`user_mobile`,`user_address`,`user_institute`,`user_nic_no`,
								`user_full_name`,`user_email` 
							   FROM 
							     tbl_system_user 
							   WHERE 
							     $filter";
						//echo '2222';				
					       $result = $conn->query($view_u);
			}
			
			else{
				echo "Invalid Calling Method!";
				
			}
			
			//echo 'mklslkfjsafj';
			
?> 
			

			
<div class="container">
   <br />
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">User View</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
							    <th>ID</th>
								<th>Type of User</th>
								<th>Position</th>
								<th>Address</th>
								<th>NIC No</th>
								<th>Company ID</th>
								<th>Mobile No</th>
								<th>Agency</th>
								<th>Full Name</th>
								<th>Email</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
						?>
						
							<tr>
							    <td><?php echo $row['user_id']; ?></td>
								<td><?php echo $row['user_category']; ?></td>
								<td><?php echo $row['user_position']; ?></td>
								<td><?php echo $row['user_address']; ?></td>
								<td><?php echo $row['user_nic_no']; ?></td>
								<td><?php echo $row['user_company_id']; ?></td>
								<td><?php echo $row['user_mobile']; ?></td>
								<td><?php echo $row['user_institute']; ?></td>
								<td><?php echo $row['user_full_name']; ?></td>
								<td><?php echo $row['user_email']; ?></td>
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['user_id'].'" id="update"><a href="user_edit.php?user_id=<?php echo $row['user_id'];?>"> Edit </a></button>
                                <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['user_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['user_id'].'" id="delete"> Delete </button></td>
								<?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
                            </tr>
						<?php
							}
						?>
						</tbody>
						
						</table>
					</div>
					</div>
				</div>
	</hr>

</div> 
