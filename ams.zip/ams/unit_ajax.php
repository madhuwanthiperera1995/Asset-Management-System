<?php 
			
	include 'db_connect.php';
			
		if((isset($_POST['del_id'])) && ($_POST['del_id']>0)){
				$delete ="UPDATE 
							tbl_unit_of_measure 
						  SET
							`unit_measure_active_status` = 0
						  WHERE
							`unit_measure_id`='".$_POST['del_id']."'
							";
				
				$result_del = $conn->query($delete);
		}
?>