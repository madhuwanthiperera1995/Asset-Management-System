
			<?php 
			session_start();
			include 'db_connect.php';
			
			if(isset($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';

					$unit_name = $_GET['unit_name'];
					$unit_description = $_GET['unit_description'];
					$measure_unit = $_GET['measure_unit'];
					
					$filter = "1=1";
					
					        if(isset($_GET['unit_measure_id']) && ($_GET['unit_measure_id']!=''))
							{
								$filter .= " AND `unit_measure_id` LIKE '%".$_GET['unit_measure_id']."%'";
								
							}
					
							if(isset($_GET['unit_name']) && ($_GET['unit_name']!=''))
							{
								$filter .= " AND `unit_name` LIKE '%".$_GET['unit_name']."%'";
								
							}
							
							if(isset($_GET['unit_description']) && ($_GET['unit_description']!=''))
							{
								$filter .= " AND `unit_description` LIKE '%".$_GET['unit_description']."%'";
							}
							
							
							if(isset($_GET['measure_unit']) && ($_GET['measure_unit']!=''))
							{
								$filter .= " AND `measure_unit` LIKE '%".$_GET['measure_unit']."%'";
							}
								
							
					
						
			    $view_z = "SELECT 
					            `unit_measure_id`,`unit_name`,`measure_unit`,`unit_description`
							   FROM 
							     tbl_unit_of_measure 
							   WHERE 
							     $filter";
								 
						//echo '2222';
						
					       $result = $conn->query($view_z);
			}
			
			else{
				echo "Invalid Calling Method!";
				
			}
			
			//echo 'mklslkfjsafj';
			
?> 
			

			
<div class="container">
   <br />
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">Unit of Measure View</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
							    <th>ID</th>
								<th>Name</th>
								<th>Measure Unit</th>
								<th>Description</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
								
						?>
						
							<tr>
							    <td><?php echo $row['unit_measure_id']; ?></td>
								<td><?php echo $row['unit_name']; ?></td>
								<td><?php echo $row['measure_unit']; ?></td>
								<td><?php echo $row['unit_description']; ?></td>
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['unit_measure_id'].'" id="edit"><a href="unit_of_measure_edit.php?unit_measure_id=<?php echo $row['unit_measure_id'];?>"> Edit </a></button>
                                 <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								
								
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['unit_measure_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['unit_measure_id'].'" id="delete"> Delete </button></td>
									<?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
							
							</tr>
						<?php
							}
						?>
						</tbody>
						
						</table>
					</div>
					</div>
				</div>
	</hr>

</div> 
