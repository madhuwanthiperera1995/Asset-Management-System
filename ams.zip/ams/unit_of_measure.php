<?php include 'template/header.php'; ?>

<?php
	include 'db_connect.php';
?>

<?php
				if(isset($_POST['save']))
					{	 
						    
							$unit_name = $_POST['unit_name'];
							$measure_unit = $_POST['measure_unit'];
							$unit_description = $_POST['unit_description'];
							
							
							$sql = "INSERT INTO tbl_unit_of_measure(
							unit_name,measure_unit,unit_description)
							
							VALUES ( 
							'".$unit_name."','".$measure_unit."','".$unit_description."')";
							
							//$_SESSION['sys_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
?>

<form action="" method="POST">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Unit of Measure</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="unit_name" id="preinput">Name</label>
			</div>
			<div class="col-sm-1">
				<label for="unit_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="unit_name" id="inputid">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="unit_description" id="preinput">Description</label>
			</div>
			<div class="col-sm-1">
				<label for="unit_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="unit_description" id="inputid">
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="measure_unit" id="preinput">Measure Unit</label>
			</div>
			<div class="col-sm-1">
				<label for="measure_unit" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<select name="measure_unit" id="measure_unit" style="width:240px; height:35px" class="form-control">
						<option value="0">select</option>
						<option value="centimeter">Centimeter</option>
						<option value="meter">Meter</option>
						<option value="millimeter">Millimeter</option>
						<option value="inch">Inches</option>
						<option value="yard">Yard</option>
						<option value="feet">Feet</option>
				</select><br><br>
				<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;"><b>ADD</b></button>
			</div>
		</div>
		
</div>
</form>
<?php include 'template/footer.php'; ?>