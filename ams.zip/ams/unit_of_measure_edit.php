<!--<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>	-->

<?php

include 'template/header.php';
//echo 'jkjkjk '.$_SESSION['user_level'].'...........mmaadddddddd ';
	if((isset($_SESSION['user_level'])) && (($_SESSION['user_level']=='1') || ($_SESSION['user_level']=='2')))
	{		  
 
    include 'db_connect.php';
	
	$unit_measure_id = $_GET['unit_measure_id'];
	
	$edit = "SELECT
				*FROM
				  tbl_unit_of_measure
				WHERE
				  `unit_measure_id`= '".$_GET['unit_measure_id']."'";
				  
	$result_ed = $conn->query($edit);
	
	$row = mysqli_fetch_array($result_ed);
	
	if(isset($_POST['update'])) // when click on Update button
{
						    $unit_name = $_POST['unit_name'];
							$measure_unit = $_POST['measure_unit'];
							$unit_description = $_POST['unit_description'];
			
	 $new1 = "UPDATE 
				tbl_unit_of_measure 
					SET 
						unit_name = '$unit_name', measure_unit='$measure_unit', unit_description='$unit_description'
					WHERE 
						unit_measure_id = '$unit_measure_id'";
							
  

                        if (mysqli_query($conn, $new1)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $new1 . "
					" . mysqli_error($conn);
						 }
						 

                if($new1)
					{
						mysqli_close($conn); // Close connection
						header("location:unit_of_measure_view.php"); // redirects to all records page
						exit;
					}
					else
					{
						echo mysqli_error();
					}    							 
}

?>

<form action="" method="POST">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Assert Category</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="unit_name" id="preinput">Name</label>
			</div>
			<div class="col-sm-1">
				<label for="unit_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="unit_name" id="unit_name" value="<?php echo $row['unit_name'] ?>">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="measure_unit" id="preinput">Symbol</label>
			</div>
			<div class="col-sm-1">
				<label for="measure_unit" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<select name="measure_unit" id="measure_unit" style="width:170px; height:35px" class="form-control" value="<?php echo $row['measure_unit'] ?>">
						<option value="select" <?php if($row['measure_unit']== 'select'){ echo 'selected'; }?>>select</option>
						<option value="centimeter" <?php if($row['measure_unit']== 'centimeter'){ echo 'selected'; }?>>Centimeter</option>
						<option value="meter" <?php if($row['measure_unit']== 'meter'){ echo 'selected'; }?>>Meter</option>
						<option value="millimeter" <?php if($row['measure_unit']== 'millimeter'){ echo 'selected'; }?>>Millimeter</option>
						<option value="inch" <?php if($row['measure_unit']== 'inch'){ echo 'selected'; }?>>Inches</option>
						<option value="yard" <?php if($row['measure_unit']== 'yard'){ echo 'selected'; }?>>Yard</option>
						<option value="feet" <?php if($row['measure_unit']== 'feet'){ echo 'selected'; }?>>Feet</option>
				</select>
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="unit_description" id="preinput">Description</label>
			</div>
			<div class="col-sm-1">
				<label for="unit_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="unit_description" id="unit_description" value="<?php echo $row['unit_description'] ?>"><br><br>
				<button type="update" name="update" style="background-color:gray;">Update</button>
			</div>
		</div>
		
</div>
</form>
 <?php
	}
	else{
		echo "You do not have access to this page... Please contact admin or manager";
		?>
		<button type="home" name="home" style="background-color:gray"><a href="home_page.php">Home</a></button>
		<button type="back" name="back" style="background-color:gray"><a href="user_view.php">Back</a></button>
		<?php
	}
	
  ?>
	
</body>
</html>
