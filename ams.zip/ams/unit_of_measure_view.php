<?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var unit_name = $('#unit_name').val(); 
						var unit_description = $('#unit_description').val();
						var measure_unit = $('#measure_unit').val();
						var click='TRUE';
			
			
			url='unit_of_m_view.php?click=true&unit_name='+unit_name+'&unit_description='+unit_description+'&measure_unit='+measure_unit+'';
			//alert(url);
				
			$.ajax({
				url:'unit_of_m_view.php?click=true&unit_name='+unit_name+'&unit_description='+unit_description+'&measure_unit='+measure_unit+'',
				type: 'GET',
				data: '&unit_name='+unit_name+'&unit_description='+unit_description+'&measure_unit='+measure_unit+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
	
					function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'unit_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }		

					

</script>

<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Unit of Measure View</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="unit_name" id="preinput">Name</label>
			</div>
			<div class="col-sm-1">
				<label for="unit_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="unit_name" id="unit_name">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="unit_description" id="preinput">Description</label>
			</div>
			<div class="col-sm-1">
				<label for="unit_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="unit_description" id="unit_description">
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="measure_unit" id="preinput">Measure Unit</label>
			</div>
			<div class="col-sm-1">
				<label for="measure_unit" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<select name="measure_unit" id="measure_unit" style="width:240px; height:35px" class="form-control">
						<option value="0">select</option>
						<option value="centimeter">Centimeter</option>
						<option value="meter">Meter</option>
						<option value="millimeter">Millimeter</option>
						<option value="inch">Inches</option>
						<option value="yard">Yard</option>
						<option value="feet">Feet</option>
				</select>
		</div><br><br>
		
		<div class="row pt-2">
			<div class="col-sm-3"></div>
			<div class="col-sm-2"></div>
			<div class="col-sm-1"></div>
			<div class="col-sm-2" class="div1">
				<button type="search" name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
			</div>
		</div>
		
</div>

</div>
<!--</form>-->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>