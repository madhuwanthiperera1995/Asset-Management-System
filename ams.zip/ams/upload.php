<?php 
if(isset($_POST['save'])){
	if($_FILES['c_file']['name']){
 
		// here is the current date time timestamp
		$time = date("d-m-Y")."-".time();
 
		// here we set it to the image name
		$fileName = $_FILES['c_file']['name'];
		$fileName = $time."-".$fileName ;
 
		// upload that image into the directory name: document
		move_uploaded_file($_FILES['c_file']['tmp_name'], "document/".$fileName);
		$img="document/".$_FILES['c_file']['name'];
 
	}else{
		echo "Something went wrong";
	}
}
?>