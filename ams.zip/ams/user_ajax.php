<?php 
			
	include 'db_connect.php';
			
		if((isset($_POST['del_id'])) && ($_POST['del_id']>0)){
				$delete ="UPDATE 
							tbl_system_user 
						  SET
							`user_active_status` = 0
						  WHERE
							`user_id`='".$_POST['del_id']."'
							";
				
				$result_del = $conn->query($delete);
		}
		
		
	?>