
<!--
<!DOCTYPE html>
<html lang="en">
<head>
		<title>
			Home Page
		</title>
		      <meta charset="utf-8">
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body> -->

<?php
include 'template/header.php';
//echo 'jkjkjk '.$_SESSION['user_level'].'...........mmaadddddddd ';
	if((isset($_SESSION['user_level'])) && (($_SESSION['user_level']=='1') || ($_SESSION['user_level']=='2')))
	{		  
 

	include 'db_connect.php';
	
	$user_id = $_GET['user_id'];
	
	$edit_u = "SELECT *FROM tbl_system_user WHERE `user_id`='".$_GET['user_id']."'";	

    $result_edu = $conn->query($edit_u);
	
	$row = mysqli_fetch_array($result_edu);
	
	if(isset($_POST['update'])) // when click on Update button
{    
							$user_category = $_POST['user_category'];
							$user_institute = $_POST['user_institute'];
							$user_f_name = $_POST['user_f_name'];
							$user_l_name = $_POST['user_l_name'];
							$user_full_name = $_POST['user_full_name'];
							$user_nic_no = $_POST['user_nic_no'];
							$user_email = $_POST['user_email'];
							$user_mobile = $_POST['user_mobile'];
							$user_address = $_POST['user_address'];
							$user_company_id = $_POST['user_company_id'];
							$user_name = $_POST['user_name'];
							$user_password = $_POST['user_password'];
							$date_of_join = $_POST['date_of_join'];
							$user_position = $_POST['user_position'];
							$user_level = $_POST['user_level'];
						
						 echo $new2 = "UPDATE 
									tbl_system_user 
								  SET 
										user_category = '$user_category',user_institute = '$user_institute',user_f_name = '$user_f_name',user_l_name = '$user_l_name',
										user_full_name = '$user_full_name', user_nic_no = '$user_nic_no',user_email = '$user_email',user_mobile = '$user_mobile',
										user_address = '$user_address',user_company_id = '$user_company_id',user_name = '$user_name', user_password = '$user_password',
										date_of_join = '$date_of_join', user_position = '$user_position', user_level='$user_level'
									WHERE 
										user_id = '$user_id'";
							
  

                        if (mysqli_query($conn, $new2)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $new2 . "
					" . mysqli_error($conn);
						 }
						 

						if($new2)
							{
								mysqli_close($conn); // Close connection
								header("location:user_view.php"); // redirects to all records page
								exit;
							}
							else
							{
								echo mysqli_error();
							}    							 
							}
			?>


<form action="" method="POST">


<div class="container mt-5">
  <div class="row pt-6"><center>
     <b><label for="newuser" id="preinput" class="form_style"><font size="6px" color="black">Add New User</font></label></b></center>
	</div><br>
	

	
  <div class="row pt-2">
			<div class="col-sm-2">
			<label for="user_category" id="preinput">Type of User</label>
			</div>
			<div class="col-sm-1">
				<label for="user_category" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  <select name="user_category" id="user_category" style="width:220px; height:35px" class="form-control" value="<?php echo $row['user_category'] ?>">
				  <option value="select"<?php if($row['user_category']== 'select'){ echo 'selected'; }?>>Select</option>
				  <option value="1"<?php if($row['user_category']== '1'){ echo 'selected'; }?>>Super Admin</option>
				  <option value="2"<?php if($row['user_category']== '2'){ echo 'selected'; }?>>Admin</option>
				  <option value="3"<?php if($row['user_category']== '3'){ echo 'selected'; }?>>User</option>
				  </select>
				  
			</div> 
					
					<div class="col-sm-1"></div>
			
					<div class="col-sm-2">
					<label for="user_mobile" id="preinput">Mobile No</label>
					</div>
					<div class="col-sm-1">
						<label for="user_mobile" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" style="width:220px; height:35px" class="form-control" name="user_mobile" id="inputid" value="<?php echo $row['user_mobile'] ?>">
					</div>
					<div class="col-sm-1"></div>
			
  </div> 
  
  <div class="row pt-2">
			<div class="col-sm-2">
			<label for="user_institute" id="preinput">Agency</label>
			</div>
			<div class="col-sm-1">
				<label for="user_institute" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				  
				  <select name="user_institute" style="width:220px; height:35px"  id="user_institute" class="form-control" value="<?php echo $row['user_institute'] ?>">>
					  <option value="select" <?php if($row['user_institute']== 'select'){ echo 'selected'; }?>>Select</option>
					  <option value="101"<?php if($row['user_institute']== '101'){ echo 'selected'; }?>>NTC</option>
					  <option value="102"<?php if($row['user_institute']== '102'){ echo 'selected'; }?>>SLR</option>
					  <option value="100"<?php if($row['user_institute']== '100'){ echo 'selected'; }?>>SLTB</option>
					  <option value="103"<?php if($row['user_institute']== '103'){ echo 'selected'; }?>>WPPRPTA</option>
				  </select>
			</div>

			<div class="col-sm-1"></div>
			
			<div class="col-sm-2">
			<label for="user_company_id" id="preinput">Company ID</label>
			</div>
			<div class="col-sm-1">
				<label for="user_company_id" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
			<input type="text" class="form-control" name="user_company_id" style="width:220px; height:35px" id="inputid" value="<?php echo $row['user_company_id'] ?>">
			</div>			
			
					
  </div>
  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_position" id="preinput">Position</label>
					</div>
					<div class="col-sm-1">
						<label for="user_position" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_position" style="width:220px; height:35px" id="inputid" value="<?php echo $row['user_position'] ?>">
					</div>

					<div class="col-sm-1"></div>
					    
					<div class="col-sm-2">
					<label for="user_name" id="preinput">User Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_name" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_name'] ?>">
					</div> 
								

  </div>
  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_full_name" id="preinput">User Full Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_full_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_full_name" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_full_name'] ?>">
					</div> 
					
					<div class="col-sm-1"></div>
					
					<div class="col-sm-2">
					<label for="user_password" id="preinput">Password</label>
					</div>
					<div class="col-sm-1">
						<label for="user_password" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="password" class="form-control" name="user_password" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_password'] ?>">
					</div> 
			
					
  </div>
  

  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_f_name" id="preinput">First Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_f_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_f_name" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_f_name'] ?>">
					</div>

					
					<div class="col-sm-1"></div>
			
					<div class="col-sm-2">
					<label for="date_of_join" id="preinput">Date of Join</label>
					</div>
					<div class="col-sm-1">
						<label for="date_of_join" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="date" class="form-control" name="date_of_join" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['date_of_join'] ?>">
					</div>
  </div>
  
    
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_l_name" id="preinput">Last Name</label>
					</div>
					<div class="col-sm-1">
						<label for="user_l_name" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_l_name" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_l_name'] ?>">
					</div> 

					<div class="col-sm-1"></div>
					
					<div class="col-sm-2">
					<label for="user_level" id="preinput">User Level</label>
					</div>
					<div class="col-sm-1">
						<label for="user_level" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
						  
						  <select name="user_level" style="width:220px; height:35px"  id="user_level" class="form-control" value="<?php echo $row['user_level'] ?>">
							  <option value="select" <?php if($row['user_level']== 'select'){ echo 'selected'; }?>>Select</option>
							  <option value="1"<?php if($row['user_level']== '1'){ echo 'selected'; }?>>Admin</option>
							  <option value="2"<?php if($row['user_level']== '2'){ echo 'selected'; }?>>Manager</option>
							  <option value="3"<?php if($row['user_level']== '3'){ echo 'selected'; }?>>Officer</option>
						  </select>
					</div>					
								
  </div>
  

  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_email" id="preinput">E-mail</label>
					</div>
					<div class="col-sm-1">
						<label for="user_email" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_email" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_email'] ?>">
					</div> 
					
  </div>
  
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_address" id="preinput">Address</label>
					</div>
					<div class="col-sm-1">
						<label for="user_address" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_address" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_address'] ?>">
					</div>

					
  </div>
  

  
    
  <div class="row pt-2">
					<div class="col-sm-2">
					<label for="user_nic_no" id="preinput">NIC No</label>
					</div>
					<div class="col-sm-1">
						<label for="user_nic_no" id="preinput">:</label>
					</div>
					<div class="col-sm-2">
					<input type="text" class="form-control" name="user_nic_no" style="width:220px; height:35px" id="inputid"  value="<?php echo $row['user_nic_no'] ?>">
					</div> 
					
					<div class="col-sm-1"></div>
					
					<div class="col-sm-2">
					
					</div>
					<div class="col-sm-1">
						<button type="update" name="update" style="background-color:gray">Update</button>
					</div>
					<div class="col-sm-2">
					
					</div>
  </div>
   
 </div>
 </form>
 
 <?php
	}
	else{
		echo "You do not have access to this page... Please contact admin or manager";
		?>
		<button type="home" name="home" style="background-color:gray"><a href="home_page.php">Home</a></button>
		<button type="back" name="back" style="background-color:gray"><a href="user_view.php">Back</a></button>
		<?php
	}
	
  ?>
	
</body>
</html>
