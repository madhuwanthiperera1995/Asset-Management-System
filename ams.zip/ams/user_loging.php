	<?php session_start(); ?>	
		<!DOCTYPE html>
			<html>
				<head>
					<title>
						User_Loging
					</title>
					
			  <meta name="viewport" content="width=device-width, initial-scale=1">
			  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
			  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
			  <style>
			  img.background {
				  position: absolute;
				  left: 0px;
				  top: 0px;
				  z-index: -1;
				  width: 100%;
				  height: 100%;
				  -webkit-filter: blur(10px);
				  filter: blur(10px);
				  }
			  </style>
			  
			  </head>
			  
			  
			<body>
			<img class="background" src="logo.png" alt="Aleq">

						<?php
							
							
								
						?>

						<?php
						$_session['user_id'] = '';
						$_session['user_name'] = '';
						$_SESSION['user_level']='';
						$_SESSION['user_full_nm']='';
								if(isset($_POST['submit']))
								{	 
							
							include 'db_connect.php';
							
							

							echo $loging = "SELECT `user_id`,`user_f_name`,`user_l_name`,`user_level` FROM tbl_system_user WHERE 
							user_name = '".$_POST['user_name']."'
							AND
							user_password = '".$_POST['user_password']."'
							AND
							`user_active_status` = 1 ";
							
							
							 $result = $conn->query($loging);
							 
							 $rows = mysqli_num_rows($result);
					if($rows==1){
						
						echo 'login successfull';
							
							$rw = 	$result->fetch_array();			
				
											$_session['user_id']= $rw['user_id'];
											$_session['user_name']= $rw['user_f_name'].' '.$rw['user_l_name'];
											$_SESSION['user_level'] = $rw['user_level'];
											$_SESSION['user_full_nm']=$rw['user_f_name'].' '.$rw['user_l_name'];
											/* Activity Log*/
											$qry =  $conn -> real_escape_string($loging);
											
											echo $sql = "INSERT INTO tbl_activity_log (`user_id`,`module`,`activity`,`description`,`query`,`date`,`time`, `ip_address`) 
														values ('".$_session['user_id']."','user','Login','Successfull Login','".$qry."',
														NOW(),NOW(), '".$_SERVER['REMOTE_ADDR']."')" ;
														
											$sql_query = $conn->query($sql);
											
									if(!$sql_query){
										echo mysqli_error($conn); die;
									}
											header("Location: home_page.php");
											
									 
								}
								else{
									echo 'Login Failed';
									
									header("Location: user_loging.php");
								}
							}
						?>
						
						
						<?php
						 
							class log
							{  
								CONST ENVIRONMENT = 'development';

								private $act_id;
								private $user_id;
								protected $module;
								protected $activity;
								protected $description;
								protected $query;
								protected $ip_address;
								protected $date;
								protected $time;
								

								public function __construct(string $module, string $activity, string $description, string $query)
								{
									if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
										$ip_address = $_SERVER['HTTP_CLIENT_IP'];
									} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
										$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
									} else {
										$ip_address = $_SERVER['REMOTE_ADDR'];
									}
									
									if(!empty($_SESSION['user_id'])){
										$user_id = $_SESSION['user_id'];
									}else {
										  $id = 0;
										  }
									$this->user_id = $user_id;
									$this->module = $module;
									$this->activity = $activity;
									$this->description = $description;
									$this->query = $query;
									$this->ip_address = $ip_address;
								}

								public function createAction()
								{
									global $conn;

									if(!$conn) {
									   echo mysqli_error($conn); die;
									}

									if(!$sql_query){
										echo mysqli_error($conn); die;
									}

									if(ENVIRONMENT == 'development'){
										$_SESSION['msg'] = 'A new log was created ' . $this->act_id;
									}
									
								} }

						
						?>


			<form action="" method="POST">

			<div class="container-fluid pt-4 bg-primary text-white text ali-left">
			  <center><h1>Logging</h1></center>
			</div>

			<div class="container mt-5">
					<div class="row pt-2">
					
						<div class="col-sm-1"></div>
						<div class="col-sm-11">
							<label for="assert_management" id="preinput"><font size="6px"><b>Assert Management System- Makumbura Multi Modal Center</b></font></label>
						</div>
					</div><br><br><br>
					
					
					
					<div class="row pt-2">
						<div class="col-sm-3"></div>
						<div class="col-sm-2">
							<label for="user_name" id="preinput"><b>User Name</b></label>
						</div>
						<div class="col-sm-1">
							<label for="user_name" id="preinput"><b>:</b></label>
						</div>
						<div class="col-sm-2">
							<input type="text" class="form-control" name="user_name" id="inputid">
						</div>
					</div><br>
					
					<div class="row pt-2">
						<div class="col-sm-3"></div>
						<div class="col-sm-2">
							<label for="user_password" id="preinput"><b>Password</b></label><br><br><br>
							<button type="submit" name="submit">Loging</button>
						</div>
						<div class="col-sm-1">
							<label for="user_password" id="preinput"><b>:</b></label>
						</div>
						<div class="col-sm-2">
							<input type="password" class="form-control" name="user_password" id="inputid"><br>

						</div>
					</div>
					
			</div>
			</form>
			</body>
			</html>
			

