  <?php include 'template/header.php'; ?>
  
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		$('#search').click(function(){
			//alert('function called');
			var user_category = $('#user_category').val(); 
			//alert(user_category);
			var user_company_id = $('#user_company_id').val();
			var user_position = $('#user_position').val();
			var user_mobile = $('#user_mobile').val(); 
			var user_address = $('#user_address').val();
			var user_institute = $('#user_institute').val();
			var user_nic_no = $('#user_nic_no').val(); 
			
			var click='TRUE';
			
			/*$('#data_table tbody:last_child').append()(
				'<tr>'+
					'<th>'+user_category_type+'</th>'+
					'<th>'+user_company_id+'</th>'+
					'<th>'+user_position+'</th>'+
					'<th>'+user_mobile+'</th>'+
					'<th>'+user_address+'</th>'+
					'<th>'+user_institute+'</th>'+
					'<th>'+user_nic_no+'</th>'+
				'</tr>'
			);*/
			//alert($("#myform input").serialize());
			url='a_master_view.php?click=true&user_category='+user_category+'&user_institute='+user_institute+'';
			//alert(url);
			
			$.ajax({
				url:'u_view.php?click=true&user_category='+user_category+'&user_institute='+user_institute+'',
				type: 'GET',
				data: '&user_category='+user_category+'&user_company_id='+user_company_id+'&user_position='+user_position+'&user_mobile='+user_mobile+'&user_address='+user_address+'&user_institute='+user_institute+'&user_nic_no='+user_nic_no+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
		});
	});
	
	                   function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'user_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }		
</script>


<!--<form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">-->
<div class="div1">

<div class="container mt-5">
							<div class="container mt-5">
							  <div class="row pt-6"><center>
								</div><br>

							<div class="row pt-2">
										<div class="col-sm-2">
										    <label for="user_category" id="preinput">Type of User</label>
										</div>
										<div class="col-sm-1">
											<label for="user_category" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											
											  <select name="user_category" id="user_category" style="width:160px; height:35px;" class="form-control">
												  <option value="0">select</option>
												  <option value="2">Admin</option>
												  <option value="1">Super Admin</option>
												  <option value="3">User</option>
											  </select>
											  
										</div>
										
										<div class="col-sm-2">
										<label for="user_company_id" id="preinput">Company ID</label>
										</div>
										<div class="col-sm-1">
											<label for="user_company_id" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" style="width:160px; height:35px;" name="user_company_id" id="user_company_id" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="user_position" id="preinput">Position</label>
										</div>
										<div class="col-sm-1">
											<label for="user_position" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" style="width:160px; height:35px;" name="user_position" id="user_position" >
										</div>
										
										<div class="col-sm-2">
										<label for="user_mobile" id="preinput">Mobile No</label>
										</div>
										<div class="col-sm-1">
											<label for="user_mobile" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" class="form-control" style="width:160px; height:35px;" name="user_mobile" id="user_mobile" >
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="user_address" id="preinput">Address</label>
										</div>
										<div class="col-sm-1">
											<label for="user_address" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<input type="text" style="width:160px; height:35px" class="form-control" name="user_address" id="user_address" >
										</div>
										
										<div class="col-sm-2">
										<label for="user_institute" id="preinput">Agency</label>
										</div>
										<div class="col-sm-1">
											<label for="user_institute" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											<select name="user_institute" id="user_institute" style="width:160px; height:35px;" class="form-control">
												  <option value="0">select</option>
												  <option value="101">NTC</option>
												  <option value="102">SLR</option>
												  <option value="100">SLTB</option>
												  <option value="103">WPPRPTA</option>
											  </select>
											  
										
										</div>
							</div>

							<div class="row pt-2">
										<div class="col-sm-2">
										<label for="user_nic_no" id="preinput">NIC No</label>
										</div>
										<div class="col-sm-1">
											<label for="user_nic_no" id="preinput">:</label>
										</div>
										<div class="col-sm-2" class="div1">
											  <input type="text" class="form-control" style="width:160px; height:35px;" name="user_nic_no" id="user_nic_no" >
										</div>
										
									
							</div><br>

							<div class="row pt-2">
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
										
										<div class="col-sm-2"></div>
										
										<div class="col-sm-1"></div>
												
												<div class="col-sm-2"></div>
												
												<div class="col-sm-1" class="div1">
													<button  name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
												</div>
												<div class="col-sm-2"></div>
										</div>
							</div>

</div>

</div>
</form>

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>

