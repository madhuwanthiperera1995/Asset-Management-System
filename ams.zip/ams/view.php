<?php
include 'db_connect.php';

?>