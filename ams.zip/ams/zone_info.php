<?php include 'template/header.php'; ?>

<?php
	include 'db_connect.php';
?>

<?php
				if(isset($_POST['save']))
					{	 
						    
							$zone_name = $_POST['zone_name'];
							$zone_description = $_POST['zone_description'];
							$zone_code = $_POST['zone_code'];
							
							
							$sql = "INSERT INTO tbl_zone_info(
							zone_name,zone_description,zone_code,zone_active_status)
							
							VALUES ( 
							'".$zone_name."','".$zone_description."','".$zone_code."',1)";
							
							//$_SESSION['sys_id'];
						 if (mysqli_query($conn, $sql)) {
							echo "New record created successfully !";
						 } else {
							echo "Error: " . $sql . "
					" . mysqli_error($conn);
						 }
						 mysqli_close($conn);
					}
?>

<form action="" method="POST">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Zone Information</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="zone_name" id="preinput">Zone Name</label>
			</div>
			<div class="col-sm-1">
				<label for="zone_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="zone_name" id="inputid">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="zone_description" id="preinput">Zone Description</label>
			</div>
			<div class="col-sm-1">
				<label for="zone_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="zone_description" id="inputid">
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="zone_code" id="preinput">Zone Code</label>
			</div>
			<div class="col-sm-1">
				<label for="zone_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2">
				<input type="text" class="form-control" style="width:240px; height:35px" name="zone_code" id="inputid"><br><br>
				<button type="submit" name="save" style="background-color:gray; width:100px; height:40px;"><b>ADD</b></button>
			</div>
		</div>
		
</div>
</form>
<?php include 'template/footer.php'; ?>