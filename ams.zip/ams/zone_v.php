
			<?php 
			session_start();
			include 'db_connect.php';
			
			if(isset($_GET['click'])){
				$action = $_GET['click'];
                    //echo 'alert 11';

					$zone_name = $_GET['zone_name'];
					$zone_code = $_GET['zone_code'];
					$zone_description = $_GET['zone_description'];
					
					$filter = "1=1";
					
					        if(isset($_GET['zone_id']) && ($_GET['zone_id']!='0'))
							{
								$filter .= " AND `zone_id` LIKE '%".$_GET['zone_id']."%'";
								
							}
					
							if(isset($_GET['zone_name']) && ($_GET['zone_name']!='%'))
							{
								$filter .= " AND `zone_name` LIKE '%".$_GET['zone_name']."%'";
								
							}
							
							if(isset($_GET['zone_code']) && ($_GET['zone_code']!=''))
							{
								$filter .= " AND `zone_code` LIKE '%".$_GET['zone_code']."%'";
							}
								
							if(isset($_GET['zone_description']) && ($_GET['zone_description']!=''))
							{
								$filter .= " AND `zone_description` LIKE '%".$_GET['zone_description']."%'";
							}
					
						
			    $view_z = "SELECT 
					            `zone_id`,`zone_name`,`zone_code`,`zone_description`
							   FROM 
							     tbl_zone_info 
							   WHERE 
							     $filter";
								 
						//echo '2222';
						
					       $result = $conn->query($view_z);
			}
			
			else{
				echo "Invalid Calling Method!";
				
			}
			
			//echo 'mklslkfjsafj';
			
?> 
			

			
<div class="container">
   <br />
   
<hr>
		<div class="row">
				<div class="col-md-12">
					<div class="panel-heading">Zone Information</div>
					<div class="panel-body">
						<table class="table table-hover table-scriped table-bordered" id="data_table" border="1" width="100%">
						<thead>
							<tr>
							    <th>ID</th>
								<th>Zone Name</th>
								<th>Zone Code</th>
								<th>Zone Description</th>
								<th>Edit/Delete</th>
							</tr>
						</thead>
						<tbody>
						
						<?php 
							while($row = $result->fetch_assoc()) {
								
						?>
						
							<tr>
							    <td><?php echo $row['zone_id']; ?></td>
								<td><?php echo $row['zone_name']; ?></td>
								<td><?php echo $row['zone_code']; ?></td>
								<td><?php echo $row['zone_description']; ?></td>
								<td><button type="button" name="update" class="btn btn-warning bt-xs update" id="'.$row['zone_id'].'" id="edit"><a href="zone_edit.php?zone_id=<?php echo $row['zone_id'];?>"> Edit </a></button>
                                  <?php
									
										if(isset($_SESSION['user_level']) && ($_SESSION['user_level']=='1'))
										{
								?>
								
								
								<button type="button" name="delete" onclick="confirmact_del(<?php echo $row['zone_id']; ?>)" class="btn btn-danger bt-xs delete" id="'.$row['zone_id'].'" id="delete"> Delete </button></td>
								<?php
									}
									else{
										echo 'you cannot delete this records';
										}
										
								?>
							
							</tr>
						<?php
							}
						?>
						</tbody>
						
						</table>
					</div>
					</div>
				</div>
	</hr>

</div> 
