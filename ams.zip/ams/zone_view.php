<?php  include 'template/header.php'; ?> 

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  
<script type="text/javascript">
	$(document).ready(function(){
		
		
		    $('#search').click(function(){
						//alert('function called');
						var zone_name = $('#zone_name').val(); 
						var zone_code = $('#zone_code').val();
						var zone_description = $('#zone_description').val();
						var click='TRUE';
			
			
			url='zone_v.php?click=true&zone_name='+zone_name+'&zone_code='+zone_code+'&zone_description='+zone_description+'';
			//alert(url);
				
			$.ajax({
				url:'zone_v.php?click=true&zone_name='+zone_name+'&zone_code='+zone_code+'&zone_description='+zone_description+'',
				type: 'GET',
				data: '&zone_name='+zone_name+'&zone_code='+zone_code+'&zone_description='+zone_description+'',
				 
				success: function(data){
					//alert(data);
					$("#div_result").html(data);
					console.log(data_table);
				}
			});
			//}
			//else{
			//	alert('please add filter options');
			//}
			
		});
	});
	
				function confirmact_del(del_id) {
						//var confirmact_del = confirm("Are you want to delete?");
						
						if (confirm("Are you want to delete?")) {
							
						  $.ajax({
							  type:'POST',
							  url:'zone_ajax.php',
							  data:{del_id:del_id},
							  success : function(data){
								  alert(data);
							  }
						  })
						  
						} 
						 else {
						  alert("Delete canceled");
						}
					  }		

					

</script>

<!-- <form id="myform" method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> -->
<div class="div1">

<div class="container mt-5">

 
  <div class="row pt-2"><center>
   <div class="col-sm-12"><font size="6px"><b>Zone Information View</b></font></div></center>
  </div><br>
  
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="zone_name" id="preinput">Zone Name</label>
			</div>
			<div class="col-sm-1">
				<label for="zone_name" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="zone_name" id="zone_name">
			</div>
	    </div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="zone_code" id="preinput">Zone Code</label>
			</div>
			<div class="col-sm-1">
				<label for="zone_code" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="zone_code" id="zone_code">
			</div>
		</div>
		
		<div class="row pt-2">
		    <div class="col-sm-3"></div>
			<div class="col-sm-2">
				<label for="zone_description" id="preinput">Zone Description</label>
			</div>
			<div class="col-sm-1">
				<label for="zone_description" id="preinput">:</label>
			</div>
			<div class="col-sm-2" class="div1">
				<input type="text" class="form-control" style="width:240px; height:35px" name="zone_description" id="zone_description">
			</div>
		</div><br>
		
		<div class="row pt-2">
			<div class="col-sm-3"></div>
			<div class="col-sm-2"></div>
			<div class="col-sm-1"></div>
			<div class="col-sm-2" class="div1">
				<button type="search" name="search" id="search" style="background-color:gray; width:100px; height:40px;"><b>Search</b></button>
			</div>
		</div>
		
</div>

</div>
<!--</form>-->

<div id="div_result"></div>
<?php include 'template/footer.php'; ?>